# Ada Church base optimizer — reference folder

Everything recoverable about how **Closure's Toolbox** (`tools.adachurch.com/#/base`) works
and how it looks, assembled 2026-08-15 so a redesign can be built against it without access
to the tool.

## Start here

| File | Lines | What it is |
|---|---|---|
| **`PROMPT.md`** | ~180 | Paste-ready brief. Self-contained — the domain, the seven screens, the data shapes, the real density numbers, and what to keep vs. fix. **This is the one to paste into v0.** |
| `HOW-IT-WORKS.md` | ~410 | The mechanics. Domain model, the clause/scoring engine, the assignment search, simulate vs. report, every exposed formula, the full API contract, and where a reimplementer has to decide for themselves. |
| `DESIGN.md` | ~485 | The visual system. Every colour token, the type scale, spacing, the literal grid definition, component-by-component DOM anatomy with states, motion, and the chart treatment — all cited to line numbers in the real stylesheet. |
| `SPEC.md` | ~407 | The UI/IA layer: screen inventory, exact room placement, exhaustive control inventory, states. |
| `API.md` | ~120 | The eleven endpoints with real captured requests and responses. |
| `SCREENSHOTS.md` + `screens/` | 24 images | The live tool, in flow order. |
| `source/` | — | Raw material: the tool's own JS modules, its 474 KB stylesheet, real API fixtures, the author's algorithm PDF, and the same author's earlier open implementation. |

## How this was obtained

The Discord login gates only the app shell and the API — `/css/style.css`,
`/js/views/base-builder.js` and `/js/riic-layout.js` all serve unauthenticated, and the
modules are **not minified**. So the UI, the layout constants, and the request construction
were read directly from source. The API contract and the response payloads were captured by
calling the eleven endpoints from the authenticated page. The algorithm itself comes from
the author's own internal write-up (`source/ALGORITHM-REFERENCE-PDF.txt`) cross-checked
against their earlier open implementation in `source/prior-art/`.

The scoring engine runs server-side, so the search strategy is described from the author's
reference and from observed behaviour, and every inference is marked as one.

## The three things worth knowing before reading anything else

1. **Buffs cross rooms.** A Control Center operator raises Trading Post efficiency. No
   per-room number is a function of that room's occupants alone.
2. **The optimizer proposes, it does not apply.** Its whole output is
   `{assignment, score, per_slot}` and the user accepts it room by room.
3. **The objective is production-weighted.** Observed per-slot scores: production rooms
   63–74, Control Center 50, Workshop 25, Reception 18, Training 15, Office 12,
   dormitories 1.3–1.6, activity rooms exactly 0.
