class Planner {
    // Singleton
    constructor() {
        if (Planner._instance) {
            return Planner._instance;
        }
        Planner._instance = this;
    }

    /**
     * Using a list of input operators and a base setup, sends back a 3-tiered rotation
     * 
     * @param {Array[Operator]} operators: list of operators owned by the player, as imported
     * @param {Object} setup: object with 4 properties indicating the number and levels of FAC/TPs
     * @param {Boolean} isMoraleMicro: true if the player is willing to micromanage the morale of specific
     * operators, such as Dusk / Ling in a PI combo or some workshop operators requiring those in dorm to have
     * a morale below a certain threshold
     * @param {Integer} assumePromotionLevel: The promotion (elite) level operators will be forced to have
     * to ensure they have access to relevant skills.
     */
    planify(operators, base, isMoraleMicro, assumePromotionLevel) {
        if(assumePromotionLevel > 0){
            for(let operator of operators){
                if(operator.elite < assumePromotionLevel){
                    operator.elite = parseInt(assumePromotionLevel);
                }
            }
        }

        /***************************************************************
         ********** Evaluating combos and available operators **********
         ***************************************************************/

        // ========== SPECIAL ==========

        let piSrSquadScore = this.evaluatePerceptionInformationSoundlessResonance(operators, base, isMoraleMicro);
        console.log(piSrSquadScore);
        let wpSquadScore = this.evaluateWordlyPlight(operators, base, isMoraleMicro);
        console.log(wpSquadScore);
        let automationScore = this.evaluateAutomation(operators, base);
        console.log(automationScore);
        let pinusScore = this.evaluatePinus(operators, base);
        console.log(pinusScore);
        let glasgowScore = this.evaluateGlasgow(operators, base);
        console.log(glasgowScore);
        let karlanScore = this.evaluateJayeAndKT(operators, base);
        console.log(karlanScore);
        let monhunScore = this.evaluateMonHun(operators);
        console.log(monhunScore);
        let abyHuntScore = this.evaluateAbyssalHunters(operators);
        console.log(abyHuntScore);
        let jessBSWScore = this.evaluateJessicaBSW(operators);
        console.log(jessBSWScore);
        let dunMesScore = this.evaluateDungeonMeshi(operators, base);
        console.log(dunMesScore);
        let babelScore = this.evaluateBabel(operators);
        console.log(babelScore);
        let puddingScore = this.evaluatePudding(operators);
        console.log(puddingScore);

        // ========== FACTORY ==========

        // ---------- Teams ----------

        let vermeilScore = this.evaluateOperatorForFAC(
            operators, base, "char_190_clour", VERMEIL_AND_BUBBLE_TEAM_CANDIDATES, 1
        );
        console.log(vermeilScore);
        let bubbleScore = this.evaluateOperatorForFAC(
            operators, base, "char_381_bubble", VERMEIL_AND_BUBBLE_TEAM_CANDIDATES, 1
        );
        console.log(bubbleScore);


        // ---------- Singles ----------

        //let 

        // ========== TRADING POST ==========

        // ---------- Teams ----------
        let shamareScore = this.evaluateShamareSquad(operators);
        console.log(shamareScore);
        //let penguinScore = this.evaluatePenguinLogistics(operators);
        //console.log(penguinScore);
        //let pozyGLPScore = this.evaluatePozyGLP(operators, base);
        //console.log(pozyGLPScore);
        // TODO: E0 Jaye
        // TODO: E1 Jaye
        // TODO: Proviso

        // ---------- Singles ----------

        // ========== RECEPTION ROOM ==========

        // ---------- Teams ----------
        // Any team that requires both operators

        // ---------- Solos ----------
        // Any operator that requires the 2nd slot to be empty

        // ---------- Singles ----------

        // ========== POWER PLANT ==========

        // ========== HUMAN RESOURCES (OFFICE) ==========


        // ========== CONTROL CENTER ==========

        // TODO: Alter morale squad
        // TODO: Lee agency
        // TODO: Mlynar smiley squad


        /********************************************************************
         ********** Planning the rotations based on above findings **********
         ********************************************************************/


    }

    /**
     * Evaluate the player's roster to see whether it's viable to run PI/SR
     * @param {Array[Operator]} operators: list of operators owned by the player, as imported
     * @param {Base} base: the base setup of the player
     * @returns {Object}: with "rosmonPD" and "ebenPD" and their respective productivity
     * given the other operators
     */
    evaluatePerceptionInformationSoundlessResonance(operators, base, isMoraleMicro) {
        let totalPI = 0;
        let totalSR = 0;
        let useDusk = false;
        let useLing = false;
        let useWhisperain = false;
        let useSaileach = false;
        let useArturia = false;
        let useCzerny = false;
        let useIris = false;

        // Dusk & Ling require micromanaging their morale for PI generation, so skip if the player doesn't want to
        if (isMoraleMicro) {
            let ling = operators.find(e => e.id === "char_2023_ling");
            let dusk = operators.find(e => e.id === "char_2015_dusk");
            if (ling && ling.elite === 2) {
                useLing = true;
                totalPI += 10;
            }

            if (dusk) {
                useDusk = true;
                totalPI += 10;
            }
        }

        // Next to see if we can add Whisperain (and possibly Saileach) to generate more PI
        let whisperain = operators.find(e => e.id === "char_436_whispr");
        if (whisperain && whisperain.elite === 2) {
            if (base.office === 2) {
                totalPI += 10;
                useWhisperain = true;
            } else if (base.office === 3) {
                totalPI += 20;
                useWhisperain = true;
            }

            let saileach = operators.find(e => e.id === "char_479_sleach");
            if (useWhisperain && saileach && saileach.elite === 2) {
                useSaileach = true;
            }
        }

        // Now to see how much SR/PI we get from dorms
        let arturia = operators.find(e => e.id === "char_245_cello");
        let czerny = operators.find(e => e.id === "char_4047_pianst");
        let iris = operators.find(e => e.id === "char_338_iris");
        if (arturia) {
            totalSR += 5;
            useArturia = true;
        }
        if (czerny && czerny.elite === 2) {
            totalPI += base.getHighestDormLevel();
            useCzerny = true;
        }
        if (iris && iris.elite === 2) {
            totalPI += base.getHighestDormLevel();
            useIris = true;
        }

        // Now for Roscat & Eben, first we take into account their first skill
        let rosmontis = operators.find(e => e.id === "char_391_rosmon");
        let ebenholz = operators.find(e => e.id === "char_4046_ebnhlz");
        if (rosmontis) {
            totalPI += 20;
        }
        if (ebenholz) {
            totalPI += 20;
            if (ebenholz.elite === 2) {
                totalSR += Math.floor(totalPI / 2);
            } else {
                totalSR += Math.floor(totalPI / 4);
            }
        }

        return {
            "rosmonPD": rosmontis ? totalPI : 0,
            "ebenPD": ebenholz ? totalSR : 0,
            "useWhisperain": useWhisperain,
            "useSaileach": useSaileach,
            "useArturia": useArturia,
            "useCzerny": useCzerny,
            "useIris": useIris,
            "useDusk": useDusk,
            "useLing": useLing,
        };
    }

    /**
     * Evaluate the player's roster to see whether it's viable to run WP.
     */
    evaluateWordlyPlight(operators, base, isMoraleMicro) {
        let totalWP = 0;
        let useDusk = false;
        let useLing = false;
        let useMulberry = false;
        let useSaileach = false;
        let useMrNothing = false;
        let useChongyue = false;
        let useNian = false;
        let useShu = false;
        let useYu = false;
        let useJieyun = false;
        let suiCount = 0;

        // Dusk & Ling require micromanaging their morale for PI generation, so skip if the player doesn't want to
        if (isMoraleMicro) {
            let ling = operators.find(e => e.id === "char_2023_ling");
            let dusk = operators.find(e => e.id === "char_2015_dusk");
            if (ling && ling.elite === 2) {
                useLing = true;
                totalWP += 15;
            }

            if (dusk) {
                useDusk = true;
                totalWP += 15;
            }
        }

        // Next to see if we can add Mulberry (and possibly Saileach) to generate more PI
        let mulberry = operators.find(e => e.id === "char_473_mberry");
        if (mulberry && mulberry.elite === 2) {
            if (base.office === 2) {
                totalWP += 10;
                useMulberry = true;
            } else if (base.office === 3) {
                totalWP += 20;
                useMulberry = true;
            }

            let saileach = operators.find(e => e.id === "char_479_sleach");
            if (useMulberry && saileach && saileach.elite === 2) {
                useSaileach = true;
            }
        }

        // Mr. Nothing. Only the WP part, the productivity is at the end
        let mrNothing = operators.find(e => e.id === "char_455_nothin");
        if (mrNothing && mrNothing.elite === 2) {
            totalWP += 20;
            useMrNothing = true;
        }

        // On to Chungus... We have to count how many Sui siblings can be put in the base
        let chongyue = operators.find(e => e.id === "char_2024_chyue");
        let nian = operators.find(e => e.id === "char_2014_nian");
        let shu = operators.find(e => e.id === "char_2025_shu");
        let yu = operators.find(e => e.id === "char_2026_yu");
        if (chongyue) {
            useChongyue = true;
            suiCount++;
            if (nian) {
                useNian = true;
                suiCount++;
            }

            if (shu) {
                useShu = true;
                suiCount++;
            }

            if (yu) {
                useYu = true;
                suiCount++;
            }

            if (useDusk) {
                suiCount++;
            }

            if (useLing) {
                suiCount++;
            }

            // Chongyue's skill is capped at 5 siblings
            totalWP += Math.min(suiCount * 5, 25);
        }

        // Separate check for Shu that doesn't depend on Chungus, since she can provide FAC productivity with WP
        if (shu && shu.elite === 2) {
            useShu = true;
        }

        // Jieyun check, even at E0 there is some productivity, tho it's not really worth really
        let jieyun = operators.find(e => e.id === "char_4078_bdhkgt");
        let jieyunPD = 0;
        if (jieyun) {
            useJieyun = true;
            jieyunPD = Math.floor(totalWP / 5);
            if (jieyun.elite === 2) {
                jieyunPD = Math.floor(totalWP / 5) * 2;
            }
        }

        return {
            "totalWP": totalWP,
            "useDusk": useDusk,
            "useLing": useLing,
            "useMulberry": useMulberry,
            "useSaileach": useSaileach,
            "useMrNothing": useMrNothing,
            "useNian": useNian,
            "useChongyue": useChongyue,
            "useShu": useShu,
            "useYu": useYu,
            "useJieyun": useJieyun,
            "mrNothingPD": useMrNothing ? totalWP : 0,
            "jieyunPD": useJieyun ? jieyunPD : 0,
            "shuPD": useShu ? Math.floor(totalWP / 3) : 0,
        };
    }

    /**
     * Evaluate the player's roster to see whether it's viable to automation.
     */
    evaluateAutomation(operators, base) {
        let ppCount = base.getPowerPlantCount();
        let isLancetDead = false;
        let isLancetUsed = false;
        let isGreyyaltUsed = false;
        let isEunectesUsed = false;
        let isWeedyUsed = false;
        let isPassengerUsed = false;
        let isPurestreamUsed = false;
        let isWindflitUsed = false;
        let weedyPD = 0;
        let passengerPD = 0;
        let windflitPD = 0;
        let purestreamPD = 0;

        // First, we check for virtual power plants with Greyy alter/Zumama since they influence the other ops
        let greyyalt = operators.find(e => e.id === "char_1027_greyy2");
        if (greyyalt && greyyalt.elite === 2) {
            ppCount += 1;
            isLancetDead = true;
            isGreyyaltUsed = true;
        }

        let eunectes = operators.find(e => e.id === "char_416_zumama");
        if (eunectes && eunectes.elite === 2) {
            ppCount += 2;
            isEunectesUsed = true;
            isLancetUsed = true;
        }

        // Now to cover all the automation skills
        let weedy = operators.find(e => e.id === "char_400_weedy");
        if (weedy) {
            isWeedyUsed = true;
            weedyPD = ppCount * 10;
            if (weedy.elite === 2) {
                weedyPD = ppCount * 15;
            }
        }

        let purestream = operators.find(e => e.id === "char_385_finlpp");
        if (purestream && purestream.elite >= 1) {
            isPurestreamUsed = true;
            purestreamPD = base.getTradingPostCount() * 20;
        }

        // Returns on Passenger & Windflit are too low with PP, with a measly 20% at full potential
        if (base.getPowerPlantCount() === 3) {
            let passenger = operators.find(e => e.id === "char_472_pasngr");
            if (passenger && passenger.elite === 2) {
                isPassengerUsed = true;
                passengerPD = ppCount * 5;
            }

            // We only add Windflit if passenger is not used, due to the 3 slot limitation
            let windflit = operators.find(e => e.id === "char_433_windft");
            if (!isPassengerUsed && windflit && windflit.elite === 2) {
                isWindflitUsed = true;
                windflitPD = ppCount * 5;
            }
        }

        return {
            "isGreyyaltUsed": isGreyyaltUsed,
            "isWindflitUsed": isWindflitUsed,
            "isPassengerUsed": isPassengerUsed,
            "isEunectesUsed": isEunectesUsed,
            "isWeedyUsed": isWeedyUsed,
            "isLancetUsed": isLancetUsed,
            "isLancetDead": isLancetDead,
            "isPurestreamUsed": isPurestreamUsed,
            "weedyPD": weedyPD,
            "passengerPD": passengerPD,
            "windflitPD": windflitPD,
            "purestreamPD": purestreamPD,
            "totalPD": weedyPD + passengerPD + windflitPD + purestreamPD
        };
    }

    /**
     * Evaluate the player's roster to see whether it's viable to pinus sylvestris.
     * The evaluation first covers gold production, then EXP, since they are identical
     * apart from the introduction of Flametail
     */
    evaluatePinus(operators, base) {
        let isVivianaUsed = false;
        let isWildmaneUsed = false;
        let isAshlockUsed = false;
        let isFartoothUsed = false;
        let isGravelUsed = false;
        let isJusticeKnightUsed = false;
        let wildmanePDGold = 0;
        let ashlockPDGold = 0;
        let fartoothPDGold = 0;
        let gravelPDGold = 0;

        // ============== Gold evaluation part ==============

        // Vivi first, since she is an amplifier for everyone
        let viviana = operators.find(e => e.id === "char_4098_vvana");
        if (viviana && viviana.elite === 2) {
            isVivianaUsed = true;
        }

        // Now for all FAC candidates
        let wildmane = operators.find(e => e.id === "char_496_wildmn");
        if (wildmane) {
            isWildmaneUsed = true;
            wildmanePDGold = 15;
            if (wildmane.elite === 2) {
                wildmanePDGold = 25;
            }

            if(isVivianaUsed){
                wildmanePDGold += 7;
            }

            let justiceKnight = operators.find(e => e.id === "char_4000_jnight");
            if(justiceKnight){
                isJusticeKnightUsed = true;
                wildmanePDGold += 5;
            }
        }

        let ashlock = operators.find(e => e.id === "char_431_ashlok");
        if (ashlock) {
            isAshlockUsed = true;
            ashlockPDGold = 15;
            if (ashlock.elite === 2) {
                ashlockPDGold = 25;
            }

            if(isVivianaUsed){
                ashlockPDGold += 7;
            }
        }

        let fartooth = operators.find(e => e.id === "char_430_fartth");
        if (fartooth) {
            isFartoothUsed = true;
            fartoothPDGold = 15;
            if (fartooth.elite === 2) {
                fartoothPDGold = 25;
            }

            if(isVivianaUsed){
                fartoothPDGold += 7;
            }
        }

        let gravel = operators.find(e => e.id === "char_237_gravel");
        if (gravel && (gravel.elite >= 1)) {
            isGravelUsed = true;
            gravelPDGold = 35;

            if(isVivianaUsed){
                gravelPDGold += 7;
            }
        }

        let goldScore = {
            "isVivianaUsed": isVivianaUsed,
            "isWildmaneUsed": isWildmaneUsed,
            "isGravelUsed": isGravelUsed,
            "isAshlockUsed": isAshlockUsed,
            "isFartoothUsed": isFartoothUsed,
            "isJusticeKnightUsed": isJusticeKnightUsed,
            "wildmanePDGold": wildmanePDGold,
            "ashlockPDGold": ashlockPDGold,
            "fartoothPDGold": fartoothPDGold,
            "gravelPDGold": gravelPDGold,
            "totalPD": wildmanePDGold + ashlockPDGold + fartoothPDGold + gravelPDGold
        };

        // ============== EXP evaluation part ==============
        let isFlametailUsed = false;
        let flametail = operators.find(e => e.id === "char_420_flamtl");
        let wildmanePDEXP = wildmanePDGold;
        let ashlockPDEXP = ashlockPDGold;
        let fartoothPDEXP = fartoothPDGold;
        if (flametail && flametail.elite === 2) {
            isFlametailUsed = true;
            wildmanePDEXP = isWildmaneUsed ? wildmanePDGold + 10 : 0;
            ashlockPDEXP = isAshlockUsed ? ashlockPDGold + 10 : 0;
            fartoothPDEXP = isFartoothUsed ? fartoothPDGold + 10 : 0;
        }

        // Adjusting Gravel's prod if Flametail is being used.
        // For later calculations regarding rotations, Gravel will preferably be put on an async rotation
        // with only Vivi in CC or just used without Vivi/Flametail at all, for, e.g, a Bryophita metalwork team
        let gravelPDFlametail = gravelPDGold;
        if(isFlametailUsed && isGravelUsed){
            gravelPDFlametail -= 10;
        }

        let expScore = {
            "isFlametailUsed": isFlametailUsed,
            "isVivianaUsed": isVivianaUsed,
            "isWildmaneUsed": isWildmaneUsed,
            "isGravelUsed": isGravelUsed,
            "isAshlockUsed": isAshlockUsed,
            "isFartoothUsed": isFartoothUsed,
            "isJusticeKnightUsed": isJusticeKnightUsed,
            "wildmanePDEXP": wildmanePDEXP,
            "ashlockPDEXP": ashlockPDEXP,
            "fartoothPDEXP": fartoothPDEXP,
            "gravelPDGold": gravelPDFlametail,
            "totalPD": wildmanePDEXP + ashlockPDEXP + fartoothPDEXP + gravelPDFlametail
        };

        return {
            "exp": expScore,
            "gold": goldScore
        };
    }

    /**
     * Evaluate the player's roster to see whether it's viable to use the Glasgow Gang
     */
    evaluateGlasgow(operators) {
        // Morgan is the reason this squad is valid in the first place, hence why the early quit if she isn't built
        let morgan = operators.find(e => e.id === "char_154_morgan");
        if(!morgan || morgan.elite !== 2){
            return {
                "isMorganUsed": false,
                "isDelphineUsed": false,
                "isSiegeUsed": false,
                "isVinaUsed": false,
                "isIndraUsed": false,
                "isDagdaUsed": false,
                "totalPRD": 0
            };
        }

        let isMorganUsed = true;
        let isDelphineUsed = false;
        let isSiegeUsed = false;
        let isVinaUsed = false;
        let isIndraUsed = false;
        let isDagdaUsed = false;
        let totalPRD = 20; // Default for Morgan herself
        let delphine = operators.find(e => e.id === "char_4110_delphn");
        if(delphine && delphine.elite === 2){
            isDelphineUsed = true;
        }

        let siege = operators.find(e => e.id === "char_112_siege");
        if(siege){
            isSiegeUsed = true;
            totalPRD += 35;
        }

        // Vina isn't considered Glasgow, so she doesn't benefit from Morgan's 20%
        let vina = operators.find(e => e.id === "char_1019_siege2");
        if(vina){
            isVinaUsed = true;
            if(vina.elite === 2){
                totalPRD += 40;
            }else{
                totalPRD += 30;
            }
        }

        let currCount = this.__checkOperatorCount(isMorganUsed, isSiegeUsed, isIndraUsed, isDagdaUsed);
        if(currCount < 3){
            // Indra check
            let indra = operators.find(e => e.id === "char_155_tiger");
            if(indra){
                isIndraUsed = true;
                totalPRD += 20;
            }

            // Dagda check
            currCount = this.__checkOperatorCount(isMorganUsed, isSiegeUsed, isIndraUsed, isDagdaUsed);
            if(currCount < 3){
                let dagda = operators.find(e => e.id === "char_157_dagda");
                if(dagda){
                    isDagdaUsed = true;
                    totalPRD += 20;
                }
            }
        }

        if(isDelphineUsed){
            totalPRD +=  Math.min(currCount, 3) * 10;
        }

        return {
            "isMorganUsed": isMorganUsed,
            "isDelphineUsed": isDelphineUsed,
            "isSiegeUsed": isSiegeUsed,
            "isVinaUsed": isVinaUsed,
            "isIndraUsed": isIndraUsed,
            "isDagdaUsed": isDagdaUsed,
            "totalPRD": totalPRD
        };
    }

    /**
     * Evaluate the player's roster to see whether it's viable for Karlan Trade.
     * Because there are plenty of operators combos to test, we kinda have to list all the possible
     * combos within a TP
     */
    evaluateJayeAndKT(operators) {
        let gnosis = operators.find(e => e.id === "char_206_gnosis");
        let swireAlt = operators.find(e => e.id === "char_1033_swire2");
        let silverAsh = operators.find(e => e.id === "char_172_svrash");
        let degenbrecher = operators.find(e => e.id === "char_4116_blkkgt");
        let cliffheart = operators.find(e => e.id === "char_173_slchan");
        let courier = operators.find(e => e.id === "char_198_blackd");
        let matterhorn = operators.find(e => e.id === "char_199_yak");
        let jaye = operators.find(e => e.id === "char_272_strong");

        let isGnosisUsed = false;
        if(gnosis && gnosis.elite === 2){
            isGnosisUsed = true;
        }

        let operatorsToTest = [
            swireAlt, silverAsh, degenbrecher, cliffheart, courier, matterhorn, jaye
        ].filter(e => e !== undefined);

        let squads = this.__composeSquadsOf3(operatorsToTest);
        let bestPerforming;
        for(let squad of squads){
            let results = this.__getTradingPostStats(squad, isGnosisUsed);
            if(!bestPerforming || results.totalProductivity > bestPerforming.totalProductivity){
                bestPerforming = results;
            }
        }

        return {
            "isGnosisUsed": isGnosisUsed,
            "squad": bestPerforming
        };
    }

    /**
     * Evaluate the player's roster to see whether it's viable to use MonHun (Monster Hunter)
     * units.
     */
    evaluateMonHun(operators) {
        let isYatoAlterUsed = false;
        let isNoirCorneAlterUsed = false;
        let isTRCUsed = false;
        let isVermeilUsed = false;
        let trcFacPD = 0;
        let trcTPPD = 0;

        let yatoAlter = operators.find(e => e.id === "char_1029_yato2");
        let noirCorneAlter = operators.find(e => e.id === "char_1030_noirc2");
        let trc = operators.find(e => e.id === "char_4077_palico");
        let vermeil = operators.find(e => e.id === "char_190_clour");

        if(yatoAlter){
            isYatoAlterUsed = true;
        }

        if(noirCorneAlter){
            isNoirCorneAlterUsed = true;
        }

        // ========== TRC productivity ===========

        if(trc){
            trcFacPD = 5;
            trcTPPD = 5;
            isTRCUsed = true;

            if(isYatoAlterUsed){
                trcFacPD += 8;
                trcTPPD += 24;
            }

            if(isNoirCorneAlterUsed){
                trcFacPD += 4;
                trcTPPD += 12;
            }

            if(vermeil){
                isVermeilUsed = true;
                trcFacPD += 16;
            }
        }

        let bothYatoAndNoirCorneE2 = yatoAlter && yatoAlter.elite === 2
            && noirCorneAlter && noirCorneAlter.elite === 2;

        return {
            "isYatoAlterUsed": isYatoAlterUsed,
            "isNoirCorneAlterUsed": isNoirCorneAlterUsed,
            "isTRCUsed": isTRCUsed,
            "isVermeilUsed": isVermeilUsed,
            "facPD": trcFacPD,
            "tpPD": trcTPPD,
            "hasFacBuff": bothYatoAndNoirCorneE2,
            "hasTPBuff": bothYatoAndNoirCorneE2
        };
    }

    /**
     * Evaluate the player's roster to see whether it's viable to use Abyssal Hunters.
     */
    evaluateAbyssalHunters(operators) {
        let isGladiiaUsed = false;
        let isSkadiUsed = false;
        let isSpecterUsed = false;
        let isUlpianusUsed = false;
        let isAndreanaUsed = false;
        let isUnderflowUsed = false;
        let ahPD = 0;
        let underflowPD = 0;

        let gladiia = operators.find(e => e.id === "char_474_glady");
        let skadi = operators.find(e => e.id === "char_263_skadi");
        let specter = operators.find(e => e.id === "char_143_ghost");
        let ulpianus = operators.find(e => e.id === "char_4145_ulpia");
        let andreana = operators.find(e => e.id === "char_218_cuttle");
        let underflow = operators.find(e => e.id === "char_4137_udflow");

        if(underflow){
            isUnderflowUsed = true;
            if(underflow.elite === 2){
                underflowPD = 30;
                if(ulpianus){
                    isUlpianusUsed = true;
                    underflowPD += 10;
                }
            }else{
                underflowPD = 25;
                if(ulpianus){
                    underflowPD += 5;
                    isUlpianusUsed = true;
                }
            }
        }

        if(gladiia){
            isGladiiaUsed = true;
            if(skadi){
                isSkadiUsed = true;
            }
            if(specter){
                isSpecterUsed = true;
            }
            if(andreana){
                isAndreanaUsed = true;
            }
            if(ulpianus){
                isUlpianusUsed = true;
            }

            let abyssalHunterFacCount = this.__checkOperatorCount(isSkadiUsed, isSpecterUsed, isAndreanaUsed, isUlpianusUsed);
            ahPD = abyssalHunterFacCount * 5;
            if(gladiia.elite === 2){
                ahPD *= 2;
            }
        }

        return {
            "isGladiiaUsed": isGladiiaUsed,
            "isSkadiUsed": isSkadiUsed,
            "isSpecterUsed": isSpecterUsed,
            "isUlpianusUsed": isUlpianusUsed,
            "isAndreanaUsed": isAndreanaUsed,
            "isUnderflowUsed": isUnderflowUsed,
            "ahPD": ahPD,
            "underflowPD": underflowPD
        };
    }

    /**
     * Evaluate the player's roster to see whether it's viable to use Jessica alter with
     * a BSW (BlackSteel Worldwide) squad, along with Mizuki for Standardization skills
     */
    evaluateJessicaBSW(operators) {
        let isJessicaAltUsed = false;
        let isMizukiUsed = false;
        let isAlmondUsed = false;
        let almondPD = 0;
        let jessicaAndVanillaPD = 25;
        let mizukiPD = 0;

        let jessicaAlt = operators.find(e => e.id === "char_1034_jesca2");
        let mizuki = operators.find(e => e.id === "char_437_mizuki");
        let almond = operators.find(e => e.id === "char_4105_almond");

        // There is no need to check for Vanilla and OG Jessica, no way people don't have them
        if(jessicaAlt && jessicaAlt.elite === 2){
            isJessicaAltUsed = true;
            jessicaAndVanillaPD += 5;
        }

        if(mizuki && mizuki.elite === 2){
            isMizukiUsed = true;
            mizukiPD = 40; // 25 from E2 + 3*5 from E0 and having 2 other standard skills
        }

        if(almond){
            isAlmondUsed = true;
            almondPD = 25;
            if(isJessicaAltUsed){
                almondPD += 5;
            }
            if(almond.elite === 2){
                // 2% for each BSW operators in base, including Almond, excluding Jessica alt, 3x cap
                almondPD += 6;
            }
        }

        return {
            "isJessicaAltUsed": isJessicaAltUsed,
            "isMizukiUsed": isMizukiUsed,
            "isAlmondUsed": isAlmondUsed,
            "almondPD": almondPD,
            "jessicaAndVanillaPD": jessicaAndVanillaPD * 2,
            "mizukiPD": mizukiPD,
            "totalJessVaniMizuAlmondPD": almondPD + jessicaAndVanillaPD * 2 + mizukiPD, // lvl 3 FAC + single Gold
            "totalJessVaniAlmondPD": almondPD + jessicaAndVanillaPD * 2 // Single lvl 3 FAC
        };
    }

    /**
     * Evaluate the player's roster to see whether it's viable to use Jessica alter with
     * a BSW (BlackSteel Worldwide) squad, along with Mizuki for Standardization skills
     */
    evaluateDungeonMeshi(operators, base) {
        let isSenshiUsed = false;
        let isMarcilleUsed = false;
        let isLaiosUsed = false;
        let isChilchuckUsed = false;
        let monsterMeal = 0;
        let laiosSpeedRR = 0;
        let chilchuckTP = 0;
        let marcilleFAC = 0;

        let senshi = operators.find(e => e.id === "char_4143_sensi");
        let marcille = operators.find(e => e.id === "char_4141_marcil");
        let laios = operators.find(e => e.id === "char_4142_laios");
        let chilchuck = operators.find(e => e.id === "char_4144_chilc");

        if(senshi && senshi.elite === 2){
            isSenshiUsed = true;
            monsterMeal = base.getHighestDormLevel();
        }

        // Laios
        if(laios){
            isLaiosUsed = true;
            laiosSpeedRR = 29; // 5% innate + 20% base + 4% from rarity
            // + 0/8/16% based on promotion level
            if(laios.elite === 1){
                laiosSpeedRR += 8;
            }else if(laios.elite === 2){
                laiosSpeedRR += 16;
                laiosSpeedRR += (monsterMeal * 2);
            }
        }

        // Marcille
        // FAC 20% base (E0) or 30% (E2), +1% per monster meal
        if(marcille){
            isMarcilleUsed = true;
            marcilleFAC = 20;
            if(marcille.elite === 2){
                marcilleFAC += 10;
                marcilleFAC += monsterMeal;
            }
        }

        // Chilchuck
        // TP 30% (+1 cap but w/e) and +1% per monster meal
        if(chilchuck){
            isChilchuckUsed = true;
            chilchuckTP = 30;
            if(chilchuck.elite === 2){
                chilchuckTP += monsterMeal;
            }
        }

        return {
            "isSenshiUsed": isSenshiUsed,
            "isLaiosUsed": isLaiosUsed,
            "isMarcilleUsed": isMarcilleUsed,
            "isChilchuckUsed": isChilchuckUsed,
            "monsterMeal": monsterMeal,
            "laiosSpeedRR": laiosSpeedRR,
            "chilchuckTP": chilchuckTP,
            "marcilleFAC": marcilleFAC
        };
    }

    /**
     * Evaluate the player's roster to see whether it's viable to use the Babel squad,
     * which is centered around the Control Center and features Amiya, Civilight Eterna,
     * Wisadel, Ines, Hoederer and OG W.
     */
    evaluateBabel(operators) {
        let isCEUsed = false;
        let isWisadelUsed = false;
        let isInesUsed = false;
        let isHoedererUsed = false;
        let isWUsed = false;
        let hoedererPD = 0;
        let hoedererCapTP = 0;
        let wisadelInesBuffRR = 0;
        let inesSpeedRR = 0;
        let ceBuffRR = 0;
        let mdDrainGlobal = 0;

        // We don't need to check for Amiya, since everyone has her and she only needs E0
        let ce = operators.find(e => e.id === "char_4134_cetsyr");
        let wisadel = operators.find(e => e.id === "char_1035_wisdel");
        let ines = operators.find(e => e.id === "char_4087_ines");
        let hoederer = operators.find(e => e.id === "char_4088_hodrer");
        let w = operators.find(e => e.id === "char_113_cqbw");

        if(ce && ce.elite === 2){
            isCEUsed = true;
            ceBuffRR += 15;
        }

        if(wisadel){
            isWisadelUsed = true;
            wisadelInesBuffRR += 5;
            hoedererCapTP = 1;
            if(wisadel.elite === 2){
                mdDrainGlobal = 0.1;
                hoedererCapTP = 2;
                if(isCEUsed){
                    mdDrainGlobal = 0.2;
                }
            }
        }

        if(ines){
            isInesUsed = true;
            // 5% innate + 20% skill + 5% rarity bonus + 16% elite2 + external buffs
            inesSpeedRR = 30 + ceBuffRR + wisadelInesBuffRR;
            if(ines.elite === 2){
                inesSpeedRR += 16;
            }
        }

        if(w){
            isWUsed = true;
        }

        if(hoederer){
            isHoedererUsed = true;
            hoedererPD = 25;
            if(isInesUsed){
                hoedererPD += 5;
            }

            if(hoederer.elite === 2){
                hoedererPD += 5;
                if(isWUsed){
                    hoedererPD += 5;
                }
            }

        }

        return {
            "isCEUsed": isCEUsed,
            "isWisadelUsed": isWisadelUsed,
            "isInesUsed": isInesUsed,
            "isHoedererUsed": isHoedererUsed,
            "isWUsed": isWUsed,
            "hoedererPD": hoedererPD,
            "hoedererCapTP": hoedererCapTP,
            "wisadelInesBuffRR": wisadelInesBuffRR,
            "inesSpeedRR": inesSpeedRR,
            "ceBuffRR": ceBuffRR,
            "mdDrainGlobal": mdDrainGlobal
        };
    }

    /**
     * Evaluate the player's roster to see whether it's viable to use Pudding and robots
     * to get that extra 2% FAC productivity.
     * A very mediocre team, as the 2% PD does not stack with similar buffs like Kal'tsit's,
     * yet requires sacrificing some PP productivity.
     */
    evaluatePudding(operators) {
        let isPuddingUsed = false;
        let isFristonUsed = false;
        let isJKUsed = false;
        let isConfessUsed = false;
        let isPhonorUsed = false;
        let isCastle3Used = false;
        let isThrmXUsed = false;

        // We don't need to check for Amiya, since everyone has her and she only needs E0
        let pudding = operators.find(e => e.id === "char_4004_pudd");

        let friston = operators.find(e => e.id === "char_4093_frston");
        let jk = operators.find(e => e.id === "char_4000_jnight");
        let confess = operators.find(e => e.id === "char_4188_confes");
        let phonor = operators.find(e => e.id === "char_4136_phonor");
        let castle3 = operators.find(e => e.id === "char_286_cast3");
        let thrmx = operators.find(e => e.id === "char_376_therex");

        if(pudding && pudding.elite >= 1){
            isPuddingUsed = true;
        }

        if(friston) isFristonUsed = true;
        if(jk) isJKUsed = true;
        if(confess) isConfessUsed = true;
        if(phonor) isPhonorUsed = true;
        if(castle3) isCastle3Used = true;
        if(thrmx) isThrmXUsed = true;

        return {
            "isPuddingUsed": isPuddingUsed,
            "isFristonUsed": isFristonUsed,
            "isJKUsed": isJKUsed,
            "isConfessUsed": isConfessUsed,
            "isPhonorUsed": isPhonorUsed,
            "isCastle3Used": isCastle3Used,
            "isThrmXUsed": isThrmXUsed,
            "isLancetUsed": true
        };
    }

    /**
     * Evaluate the player's roster to see whether it's viable to use Shamare and her squad.
     * Note that while the team works on a TP, it increases the relative value of gold used,
     * meaning it takes less gold to make as much LMD as possible (by default 500 LMD/gold bar).
     */
    evaluateShamareSquad(operators) {
        let results = {
            shamareElite: -1,
            tequilaElite: -1,
            bibeakElite: -1,
            kafkaElite: -1,
            paprikaElite: -1,
            diamanteElite: -1,
            equivalentTpPd: 0,
            alpha: 0,
            beta: 0
        };

        let shamare = operators.find(e => e.id === "char_254_vodfox");
        // The team is subpar without E2 Shamare, so just force quit if the player doesn't have her
        if(!shamare || (shamare && shamare.elite !== 2)){
            return results;
        }
        results.shamareElite = shamare.elite;

        let tequila = operators.find(e => e.id === "char_486_takila");
        let bibeak = operators.find(e => e.id === "char_252_bibeak");
        let kafka = operators.find(e => e.id === "char_214_kafka");
        let paprika = operators.find(e => e.id === "char_4071_peper");
        let diamante = operators.find(e => e.id === "char_499_kaitou");

        // First, check what tier of gold bar value we'll be using depending on Tequila
        let barValueDefault = TP_ORDERS.GOLD_VALUES[0];
        let barValueTequila = TP_ORDERS.GOLD_VALUES[0];
        if(tequila){
            results.tequilaElite = tequila.elite;
            barValueTequila = TP_ORDERS.GOLD_VALUES[1];
            if(tequila.elite === 2){
                barValueTequila = TP_ORDERS.GOLD_VALUES[2];
            }
        }

        // Second, find the best Tailoring operator
        results.alpha = 1; // We start at one, because Shamare has it on her E0
        results.beta = 0;
        for(let operator of [bibeak, kafka, paprika, diamante]){
            if(!operator){
                continue;
            }
            results[operator.appellation.toLocaleLowerCase()+"Elite"] = operator.elite;
            if(operator.elite === 2){
                results.beta++;
            }else{
                results.alpha++;
            }
        }

        // ============= Calculating PD =============
        // Get the weighted value of LMD produced for 4-bars orders
        let weights = TP_ORDERS.WEIGHTS[1];
        if(results.beta >= 0){
            weights = TP_ORDERS.WEIGHTS[3];
        }else if(results.alpha >= 2){
            weights = TP_ORDERS.WEIGHTS[2];
        }

        let weightedLMDValue =
          weights[0] * barValueDefault * 2
        + weights[1] * barValueDefault * 3
        + weights[2] * barValueTequila * 4;

        // Get the weighted time
        let squadPD = 1.93; // 90% due to Shamare + 3% from innate PD due to operators slotted
        let times = TP_ORDERS.TIME;
        let weightedTime =
            weights[0] * times[2] / squadPD
          + weights[1] * times[3] / squadPD
          + weights[2] * times[4] / squadPD;

        // Divide both for estimated PD (TP3 as a baseline)
        let lmdPerDay = weightedLMDValue / weightedTime * 24 * 60;
        results.equivalentTpPd = roundTo((lmdPerDay / TP_DAILY_LMD[2] - 1) * 100, 2);
        return results;
    }

    /**
     * Evaluate the player's roster to see the best partners for a given core operator.
     * Used in particular for both Vermeil and Bubble
     */
    evaluateOperatorForFAC(ownedOperators, base, coreOperatorId, teamCandidates, minimumPromotion) {
        let coreOperator = ownedOperators.find(e => e.id === coreOperatorId);
        let appellation = CHARACTER_TABLE[coreOperatorId].appellation;
        if(!coreOperator || (coreOperator && coreOperator.elite < minimumPromotion)){
            return {
                "isOperatorUsed": false,
                "operatorAppellation": appellation
            };
        }

        // Retrieve all the listed operators, remove those who aren't found to save up on calcs
        let operatorsToTest = ownedOperators.filter(
            e => teamCandidates.indexOf(e.id) !== -1
        );

        // We build squads of 2, since the core operator is always present
        let squads = this.__composeSquadsOf2(operatorsToTest);
        let bestPerformingExp;
        let bestPerformingGold;
        for(let squad of squads){
            squad.push(coreOperator);
            let results = this.__getFactoryStats(squad, base);
            // Replacing EXP squad if current is better
            if(!bestPerformingExp || results.totalExpProductivity > bestPerformingExp.totalExpProductivity){
                bestPerformingExp = results;
            }

            // Replacing Gold squad if current is better
            if(!bestPerformingGold || results.totalGoldProductivity > bestPerformingGold.totalGoldProductivity){
                bestPerformingGold = results;
            }
        }

        return {
            "isOperatorUsed": true,
            "operatorAppellation": appellation,
            "squadExp": bestPerformingExp,
            "squadGold": bestPerformingGold
        };
    }

    // ================ Internal functions used by above planners ================

    /**
     * Given a list of booleans, returns an integer matching how many are true, used for counting ops
     * @param  {...any} opsUsed: a list of booleans each matching whether an operator is used or not
     * @returns {Integer} count of operators used
     */
    __checkOperatorCount(...opsUsed){
        let count = 0;
        for(let opUsed of opsUsed){
            if(opUsed === true || (opUsed !== undefined && opUsed !== null)){
                count++;
            }
        }
        return count;
    }

    /**
     * Given a list of 3 operators, return the expected stats for a lvl 3 trading post
     * @param  {Array[Operator]} ops: An array containing 2 or 3 operators (functions with less)
     */
    __getTradingPostStats(ops, gnosisBuff = false){
        // As provided by the various operators, does not include the TP one
        let buffs = {
            "productivity_flat": 0,
            "productivity_per_external_cap": 0,
            "productivity_per_total_cap": 0,
            "productivity_per_diff_max_to_current": 0,
            "cap_flat": 0,
            "cap_per_10_external_productivity": 0,
            "productivity_per_5_external_cap": 0
        };

        for(let operator of ops){
            for(let skill of operator.getActiveSkills()){
                if(!SKILLS[skill.buffId]){
                    continue;
                }

                for(let effect of Object.keys(SKILLS[skill.buffId])){
                    if(buffs[effect] !== undefined && skill.buffId.indexOf("trade") === 0){
                        buffs[effect] += SKILLS[skill.buffId][effect];
                    }
                }
            }

            // Gnosis effect added
            if(gnosisBuff && KARLAN_TRADE_OPERATORS.includes(operator.id)){
                buffs.productivity_flat -= 15;
                buffs.cap_flat += 6;
            }
        }

        // Capped at 100, not debuffed by Jaye
        let degenbrecherProductivity = Math.min(buffs.productivity_per_5_external_cap * Math.floor(buffs.cap_flat / 5), 100);

        let bonusCap =
            buffs.cap_flat
            // Jaye exclusive, cap reduction based on other ops productivity
            + buffs.cap_per_10_external_productivity * Math.floor((degenbrecherProductivity + buffs.productivity_flat) / 10);

        let totalProductivity =
            // Standard productivity
            buffs.productivity_flat
            // Swire alter exclusive
            + buffs.productivity_per_external_cap * bonusCap
            // Jaye exclusive
            + (
                + buffs.productivity_per_total_cap * (bonusCap + 10)
                + buffs.productivity_per_diff_max_to_current * (bonusCap + 10)
            ) / 2
            // Degenbrecher exclusive
            + degenbrecherProductivity
        ;

        return {
            "operator1": ops[0],
            "operator2": ops[1],
            "operator3": ops[2],
            "bonusCap": bonusCap,
            "totalCap": bonusCap + 10,
            "totalProductivity": totalProductivity
        };
    }

    /**
     * Given a list of 3 operators, return the expected stats for a factory
     * TODO: Take into account Totter's lower morale for his (de)buffs
     * TODO: Implement Waai Fu
     * TODO: restructure arguments
     * @param  {Array[Operator]} ops: An array containing 2 or 3 operators (functions with less)
     * @param  {Array[Object]} base: An array listing details about the base (number of dorms,
     * FAC & TP distribution...)
     */
    __getFactoryStats(ops, base,
        hasVivianaBuff = 0, hasFlametailBuff = 0, hasJKinPP = 0,
        bswOpInBase = 0, robotsInPPCount = 0, isGummyInTP = 0,
        monsterMealCount = 0
    ){
        // As provided by the various operators
        let buffs = {
            // ======= General =======
            "productivity_flat": 0,
            "productivity_exp_flat": 0,
            "productivity_gold_flat": 0,
            "productivity_per_hour_5_stacks": 0,
            "productivity_per_hour_10_stacks": 0,
            "cap_exp_flat": 0,
            "cap_all_flat": 0,
            // ======= Specific combos =======
            // Tragodia / Ms Christine duo
            "tragodia_present": 0,
            "christine_feasting": 0,
            // Standardization (Mizuki/Highmore)
            "productivity_per_standard_skill": 0,
            "standardization_skill_count": 0,
            "convert_RT_PS_to_standard": 0,
            // Pinus Sylvestris (Viviana/Flametail)
            "pinus_sylvestris_skill_count": 0,
            "has_wild_mane": 0,
            // Rhine Tech (Dorothy)
            "productivity_per_rhine_tech_skill": 0,
            "rhine_tech_skill_count": 0,
            // Metalwork (Bryophyta core)
            "productivity_per_metalwork": 0,
            "metalwork_skill_count": 0,
            // Vermeil
            "productivity_per_total_cap_vermeil": 0,
            "is_bubble_absent": 1,
            // Bubble
            "productivity_per_individual_cap_above_16": 0,
            "productivity_per_total_cap_bubble": 0,
            "sum_of_cap_above_16": 0,
            // Narantuya
            "productivity_gold_per_dorm_sum": 0,
            // Thorns alter, Purestream
            "productivity_gold_per_trading_post": 0,
            // Fang alter
            "productivity_per_A1_operator": 0,
            "A1_operator_count": 0,
            // Almond
            "productivity_gold_per_BSW_operator": 0,
            // Alanna
            "productivity_gold_per_robot_in_pp": 0,
            "alanna_give_me_a_hand": 0,
            // Warmy
            "is_warmy_present": 0,
            // Leto
            "leto_through_thick_and_thin": 0,
            // Waai Fu
            "waai_fu_copy_productivity": 0,
            // Minimalist
            "engineering_robot_per_facility_level_max_64": 0,
            "productivity_per_16_engineering_robot": 0,
            "productivity_per_8_engineering_robot": 0,
            // Marcille
            "productivity_per_monster_meal": 0,
            // Totter
            "productivity_flat_if_morale_diff_gt_12": 0,
            "cap_flat_if_morale_diff_gt_12": 0,
        };

        // We keep adding all the operator skills to the list of buffs...
        for(let operator of ops){
            for(let skill of operator.getActiveSkills()){
                // ...but only if they have some kind of effect, go to next skill
                if(!SKILLS[skill.buffId]){
                    continue;
                }

                for(let effect of Object.keys(SKILLS[skill.buffId])){
                    if(buffs[effect] !== undefined && skill.buffId.indexOf("manu") === 0){
                        buffs[effect] += SKILLS[skill.buffId][effect];
                    }
                }
            }

            // ===== Complementary checks =====

            // sum_of_cap_above_16 (Bubble)
            if(operator.id === "char_369_bena"){
                buffs.sum_of_cap_above_16 += 17;
            }

            if(operator.id === "char_163_hpsts" && operator.elite === 2){
                buffs.sum_of_cap_above_16 += 19;
            }

            // Bubble's skill takes precedence over Vermeil's skill
            if(operator.id === "char_381_bubble"){
                buffs.is_bubble_absent = 0;
            }

            // has_wild_mane (Wild Mane) - check necessary since WM shares the same skill with other PS
            if(operator.id === "char_496_wildmn"){
                buffs.has_wild_mane = 1;
            }

            // A1 operator count (Fang alter)
            if(A1_OPERATORS.includes(operator.id)){
                buffs.A1_operator_count += 1;
            }

            // Blacksteel Worldwide count (Almond)
            if(BSW_OPERATORS.includes(operator.id)){
                bswOpInBase += 1;
            }

            // Warmy present for Alanna buff
            if(operator.id === "char_4081_warmy"){
               buffs.is_warmy_present = 1;
            }

            // Waai Fu productivity copy, track highest PD
            // TODO: Find out how to do this crap, WTF
        }

        // Generalistic
        let allPD = 0
            + buffs.productivity_flat
            + buffs.productivity_per_hour_5_stacks  * (5/2 + 7) / 12 // 12h weighted average
            + buffs.productivity_per_hour_10_stacks * (10/2 + 2) / 12 // 12h weighted average
            // Vermeil
            + buffs.cap_all_flat * buffs.productivity_per_total_cap_vermeil * buffs.is_bubble_absent
            // Bubble
            + buffs.productivity_per_individual_cap_above_16 * buffs.sum_of_cap_above_16
            + (buffs.cap_all_flat - buffs.sum_of_cap_above_16) * buffs.productivity_per_total_cap_bubble
            // Tragodia and Ms Christine in same FAC
            + buffs.tragodia_present * buffs.christine_feasting * 30
            + buffs.productivity_per_standard_skill * (
                buffs.standardization_skill_count
                + buffs.convert_RT_PS_to_standard * (
                    buffs.rhine_tech_skill_count + buffs.pinus_sylvestris_skill_count
                )
            )
            + buffs.pinus_sylvestris_skill_count * hasVivianaBuff * 7
            + buffs.has_wild_mane * hasJKinPP * 5 // Justice Knight in PP and Wild Mane present
            + buffs.rhine_tech_skill_count * buffs.productivity_per_rhine_tech_skill
            + buffs.metalwork_skill_count * buffs.productivity_per_metalwork
            + buffs.A1_operator_count * buffs.productivity_per_A1_operator
            + (
                  Math.floor(buffs.engineering_robot_per_facility_level_max_64 * Math.min(64, base.getSumOfFacilityLevels()) / 16)
                * buffs.productivity_per_16_engineering_robot
                + Math.floor(buffs.engineering_robot_per_facility_level_max_64 * Math.min(64, base.getSumOfFacilityLevels()) / 8)
                * buffs.productivity_per_8_engineering_robot
            )
            + buffs.productivity_per_monster_meal * monsterMealCount // Marcille with external Senshi buff
            + buffs.productivity_flat_if_morale_diff_gt_12 // Totter, here assumed to never fall below 12 morale
        ;

        // Gold only
        let goldPD = 0
            + buffs.productivity_gold_flat
            + buffs.productivity_gold_per_dorm_sum * 20 // TODO: replace by actual sum of dorms
            + buffs.productivity_gold_per_trading_post * 2 // TODO: replace by actual number of TPs
            + buffs.productivity_gold_per_BSW_operator * bswOpInBase // Doesn't check just the current FAC
            + buffs.productivity_gold_per_robot_in_pp * robotsInPPCount
            + buffs.alanna_give_me_a_hand * buffs.is_warmy_present * 15 // 15% if both Warmy & Alanna present
            + buffs.pinus_sylvestris_skill_count * hasFlametailBuff * -10
        ;

        // EXP only
        let expPD = 0
            + buffs.productivity_exp_flat
            + buffs.leto_through_thick_and_thin * isGummyInTP * 35
            + buffs.pinus_sylvestris_skill_count * hasFlametailBuff * 10
            // Vermeil
            + buffs.cap_exp_flat * buffs.productivity_per_total_cap_vermeil * buffs.is_bubble_absent
            // Bubble
            + buffs.cap_exp_flat * buffs.productivity_per_total_cap_bubble
        ;

        return {
            "operator1": ops[0],
            "operator2": ops[1],
            "operator3": ops[2],
            "expCap": buffs.cap_exp_flat,
            "totalCap": buffs.cap_all_flat + buffs.cap_exp_flat,
            "totalProductivity": roundTo(allPD, 2),
            "totalExpProductivity": roundTo(allPD + expPD, 2),
            "totalGoldProductivity": roundTo(allPD + goldPD, 2)
        };
    }

    /**
     * For a list of operators given as input, returns an array containing all combos of 3 operators possible
     * @param {Array[Operator]} operators: A list of at least 3 operators
     */
    __composeSquadsOf3(operators) {
        if(!operators || operators.length < 3){
            throw new Error("Squad composition requires at least 3 operators to function");
        }
        let compositions = [];
        let op1 = 0;
        let op2 = 1;
        let op3 = 2;
        while(true){
            compositions.push([operators[op1], operators[op2], operators[op3]]);
            if(op1 === operators.length - 3){
                return compositions;
            }

            op3++;
            if(op3 === operators.length){
                op2++;
                op3 = op2 + 1;

                if(op2 === operators.length - 1){
                    op1++;
                    op2 = op1 + 1;
                    op3 = op2 + 1;
                }
            }
        }
    }

    /**
     * For a list of operators given as input, returns an array containing all pairs of operators possible
     * @param {Array[Operator]} operators: A list of at least 2 operators
     */
    __composeSquadsOf2(operators) {
        if(!operators || operators.length < 2){
            throw new Error("Squad composition requires at least 2 operators to function");
        }
        let compositions = [];
        let op1 = 0;
        let op2 = 1;
        while(true){
            compositions.push([operators[op1], operators[op2]]);
            if(op1 === operators.length - 2){
                return compositions;
            }

            op2++;
            if(op2 === operators.length){
                op1++;
                op2 = op1 + 1;
            }
        }
    }
}

let akPlanner = new Planner();