# Closure’s Toolbox — Base Optimizer Visual Design System

## Scope and evidence

This is a reconstruction brief for the Base Builder at `tools.adachurch.com/#/base`. It is grounded in `../adachurch-style.css`, `source/js/views__base-builder.js`, `source/js/riic-layout.js`, and `SCREENSHOTS.md`. The source path named in the request, `source/adachurch-style.css`, is absent. The actual supplied stylesheet is one directory above this workspace. Inline code citations identify non-obvious evidence.
“Not recoverable from CSS” means do not invent the missing detail.

## 1. Design language in one paragraph

Closure’s Toolbox is a dense, dark-first, game-adjacent operations console. It belongs to the tactical-dashboard / premium-game-UI genre, not soft SaaS. The base is a technical blueprint surrounded by compact glass-and-chrome panels.
It uses square corners, translucent hairlines, clipped industrial room silhouettes, large condensed uppercase display type, tiny widely tracked labels, ghosted pictograms, and saturated color as a terse status signal. Near-black panels, pale text, one user-selected accent, facility-color rails, and operator portraits provide most of the visual energy.
This judgement follows the token set and masks in `adachurch-style.css:27-128, 7850-9629` and the state coverage described by `SCREENSHOTS.md`.

## 2. Color tokens

### Theme and surface tokens

| Token | Dark literal value | Light literal value | Purpose |
|---|---:|---:|---|
| `--bg` | `#121212` | `#f2f3f5` | Main app/page background |
| `--bg-rgb` | `18, 18, 18` | `242, 243, 245` | Alpha compositing source |
| `--bg-panel` | `#1a1a1a` | `#ffffff` | Solid generic panel |
| `--surface-panel-1` | `#20242e` | `#ffffff` | High neutral surface |
| `--surface-panel-2` | `#141414` | `#eef0f2` | Secondary surface / light modal fallback |
| `--surface-panel-3` | `#0a0a0a` | `#e2e4e8` | Recessed surface |
| `--page-edge-bg` | `#050607` | `#e7e9ec` | Behind transparent content |
| `--fade-ink` | `#08131a` | `var(--surface-panel-2)` | Fade/mask edge |
| `--glass-rgb` | `255, 255, 255` | `10, 12, 15` | Glass alpha source |
| `--chrome-rgb` | `10, 10, 10` | `255, 255, 255` | Chrome bands |
| `--modal-bg-rgb` | `20, 20, 20` | `255, 255, 255` | Metric-chip backing |
| `--home-wipe-rgb` | `255, 255, 255` | `8, 13, 20` | Home-only wipe |
| `--home-wipe-ink` | `#08131a` | `#ffffff` | Ink on home wipe |
| `--modal-backdrop-alpha` | `0.925` | `0.09` | Backdrop darkness |
| `--modal-backdrop-blur` | `12px` | `12px` | Backdrop blur |
Dark mode changes `--modal-backdrop-alpha` to `0.4625` under `.fx-full`. The literal declarations are `adachurch-style.css:52-87`. Dark is the authored visual default. Light mode swaps neutral values and glass source values, rather than creating a second component language. In light mode RIIC modal panels use `--surface-panel-2` and explicitly remove blur (`adachurch-style.css:8606, 8699, 8798, 9021`).

### Text, borders, and interaction

| Token | Literal value / derivation | Purpose |
|---|---|---|
| `--fg` | dark `#e1e1e1`; light `#14171a` | Primary text |
| `--fg-rgb` | dark `200, 210, 220`; light `20, 23, 26` | Text alpha source |
| `--muted` | dark `rgba(207,207,207,.5)`; light `rgba(50,55,60,.5)` | Hints/footnotes |
| `--ink-dark` | `#08131a` | Text on bright fills |
| `--border` | `rgba(var(--accent-rgb), .18)` | Accent modal border |
| `--border-rgb` | `var(--accent-rgb)` | Border RGB source |
| `--surface-lo` | dark `rgba(accent,.04)`; light color-mix 4% | Quiet accent wash |
| `--surface-md` | dark `rgba(accent,.08)`; light color-mix 8% | Medium accent wash |
| `--surface-hi` | dark `rgba(accent,.14)`; light color-mix 14% | Strong accent wash |
| `--ctrl-rest` | `rgba(var(--glass-rgb), .06)` | Resting control fill |
| `--ctrl-hover` | `rgba(var(--glass-rgb), .10)` | Hover fill |
| `--ctrl-strong` | `rgba(var(--glass-rgb), .16)` | Strong/light inactive fill |
These are literal `adachurch-style.css:114-130`. The recurring un-tokenized hairlines are 1px white/glass alpha at `.05, .06, .07, .08, .10, .14,` or `.16`.

### Accent choices

| `data-accent` | `--accent` | `--accent-rgb` | `--on-accent` |
|---|---:|---:|---:|
| `teal` | `#36b5d8` | `54,181,216` | `#08131a` |
| `indigo` | `#6f7ce8` | `111,124,232` | `#ffffff` |
| `rose` | `#e85c8a` | `232,92,138` | `#ffffff` |
| `lime` | `#9ed84a` | `158,216,74` | `#08131a` |
| `slate` | `#7a8bab` | `122,139,171` | `#ffffff` |
| `custom` | `#36b5d8` | `54,181,216` | `#08131a` |
`--gold` aliases `--accent`; it is not fixed yellow. Source: `adachurch-style.css:91-125`.

### Semantic and rarity tokens

| Token | Literal value | Meaning |
|---|---:|---|
| `--gain` | `#5dcf80` | Good delta, counted contributor, synergy |
| `--gain-rgb` | `93,207,128` | Gain alpha source |
| `--loss` | `#cf5d5d` | Bad delta, removal, destructive warning |
| `--loss-rgb` | `207,93,93` | Loss alpha source |
| depletion warning | `#ff6b6b` | Morale and yield warning |
| elsewhere badge | `rgb(224,160,48)` | Already assigned |
| training event | `#7de88f` | Training complete |
| swap event | `#9d7bff` | Fiammetta swap |
| Rarity | Literal value | RGB companion |
|---|---:|---:|
| `--r1` | `#8898a8` | `136,152,168` |
| `--r2` | `#48d880` | `72,216,128` |
| `--r3` | `#48c8d8` | `72,200,216` |
| `--r4` | `#52a8ff` | `82,168,255` |
| `--r5` | `#c880ff` | `200,128,255` |
| `--r6` | `#e8c050` | `232,192,80` |
Rarity only becomes a fill through `.chip.rarity-N.active`. Each rarity chip uses `--ink-dark` for its foreground. Source: `adachurch-style.css:29-35, 1090-1095`.

### Operator-class colors

| Token | Literal value | Class |
|---|---:|---|
| `--cls-guard` | `#e87830` | Guard |
| `--cls-defender` | `#4878e8` | Defender |
| `--cls-sniper` | `#e84848` | Sniper |
| `--cls-caster` | `#9858e8` | Caster |
| `--cls-medic` | `#48d898` | Medic |
| `--cls-supporter` | `#e8b838` | Supporter |
| `--cls-vanguard` | `#58c858` | Vanguard |
| `--cls-specialist` | `#e858c8` | Specialist |
Class chips map this through per-element `--cls-color`. Source: `adachurch-style.css:37-40, 1097-1118`.

### Facility colors

| Facility | Tile/product color | Room-skill/scope color | Dark text |
|---|---:|---:|---|
| Trading Post | `#38c9fe` / layout `#55caf5` | `#2f70a0` | no |
| Factory | `#fec904` / layout `#ffca08` | `#f8d746` | yes |
| Power Plant | `#c3ff43` / layout `#c7da41` | `#99c144` | no |
| Control Center | — | `#21524f` | no |
| Training Room | — | `#6d1324` | no |
| Office | — | `#545454` | no |
| Dormitory | — | `#62caca` | no |
| Workshop | — | `#e4eb4d` | yes |
| Reception Room | — | `#ce6d45` | no |
| Activity Room | — | none supplied | — |
Tile colors are literal `adachurch-style.css:8246-8248`. Scope/skill colors are `source/js/riic-layout.js:ROOM_SKILL_TAGS`. Per-card `--facility-accent` and per-scope `--scope-color` are inline variables.

## 3. Typography

### Families

| Family | Available weights | Use |
|---|---|---|
| `Segoe UI, system-ui, sans-serif` | normal plus CSS 500/600/700 | Default UI |
| `NuberNext` | 100, 400 | Loaded, but not assigned by base rules |
| `NuberNextCondensed` | 400, 700 | Display, room names, report headings |
| `Orbitron` | variable 400–900 | Control Center version numerals |
Font faces are declared in `adachurch-style.css:1-25`. The body is Segoe at `13px` (`:148-154`).

### Type roles

| Role | Literal type | Tracking/case | Source |
|---|---|---|---|
| Page title | Condensed 700, `60.8px`, line-height `.86` | `-2px`, uppercase | `.page-title` |
| Ghost page title | Condensed 700, `142.5px` | `-4px`, uppercase | `.page-header::after` |
| Page kicker | default `.65rem` = 8.45px | `5px`, uppercase | `.page-kicker` |
| Page description | default `.8rem` = 10.4px, 1.7 | `.3px` | `.page-sub` |
| Report title | Condensed 700, 18px | `.5px` | `.riic-report-title` |
| Report section | Condensed 700, 13px | `.5px`, uppercase | `.riic-report-section-title` |
| Batch title | Condensed 700, 15px | `1.2px`, uppercase | `.riic-suggest-batch-group-title-text` |
| Room name | Condensed 700, 12px, 1.15 | `.2px` | `.riic-tile-name` |
| KPI value | default 700, 21px, 1.1 | tabular | `.riic-yield-tile-value` |
| Small metric | default 700, 15px | tabular | hero/diff values |
| Stat chip | default 400, 14px | `1px`, tabular | `.riic-stat-chip-val` |
| Body row | default 500–700, 11–12.5px | normal | picker/report/event |
| Hint | default 10–11px, 1.5–1.6 | optional .2–.4px | hint classes |
| Footnote | default 10px, 1.5 | normal | `.riic-explain-footnote` |
| Micro label | default 700, 9–10.5px | .4–1px uppercase | menu/yield labels |
| Control label | default 7px | 2.5px uppercase | `.ctrl-label` |
| CC number | Orbitron 400, 56px, .85 | normal | `.riic-cc-ver-num` |
Use `font-variant-numeric:tabular-nums` on time, levels, output, rates, and deltas. Source: `adachurch-style.css:841-867, 8314, 8352-8368, 8016-8030`.

### Wide-tracked uppercase labels

The UI intentionally whispers metadata in all caps. Use it for `.chip` (`.7rem`, `1.2px`), `.riic-mode-card-label` (`.7rem`, `1.2px`), `.riic-slot-menu-ops-title` (9px, 1px), `.riic-yield-panel-title` (10.5px, .4px), and `.riic-yield-tile-label` (9.5px, .4px). Also use it for picker badges, report section titles, batch titles, scope labels, and `.ctrl-label` (7px, 2.5px).
Do not uppercase room names, operator names, narrative hints, metric names, or events. Source: `adachurch-style.css:1044-1088, 7888-7896, 8474-8475, 8619-8623`.

## 4. Spacing, radius, borders, elevation, and density

There is no declared spacing-token ladder. The recovered practical scale is `1/2/3/4/6/7/8/9/10/12/14/16/18/20/22/24/26/28/30px`. Most component work happens at 8, 10, 12, and 14px. The layout is deliberately dense: 4–10px gaps, 1px separators, 10–14px card padding, and 20–26px only for panel shells.

| Item | Literal construction |
|---|---|
| Corners | Almost all panels and chips are `border-radius:0` |
| Pills | Skill tags, badges, toggles, and dots use `999px` / 50% |
| Default border | `1px solid rgba(var(--glass-rgb),.08)` |
| Modal border | `1px solid var(--border)` |
| Tile border | `1px solid rgba(255,255,255,.075)` |
| Chip depth | inset 0 1px 0 glass .05 plus 0 1px 2px black .35 |
| Tooltip shadow | `0 14px 34px rgba(0,0,0,.5)` |
| Portrait border | 1.5px solid white alpha .75–.85 |
| General modal shadow | not present on RIIC modal rules |
The square-corner rule is essential. Pills convey compact status. Rectangles convey actions and technical data. Source: `adachurch-style.css:1044-1088, 8121-8144, 8450-8468, 8588-8606`.

## 5. Layout

### Shell

`--sidebar-width` is fixed at `64px`. `#shell-main` flexes. `#shell-content` is full width, centered, `max-width:1400px`, and padded `24px 28px`. The top utility bar is 56px high, sticky, and padded `0 28px`. Source: `adachurch-style.css:27, 650, 659-670, 803-810`. The base page orders header, mode/action row, tally, scrollable stage, and Daily Yield. This matches `SCREENSHOTS.md:01-03,15`.

### Literal base grid

`gridTemplateColumns()` returns:
```css
64px 64px 64px 64px 64px 64px 64px 32px 64px 64px 64px 64px 32px 64px 64px 64px 32px 64px 64px 64px 64px 64px 64px
```
`#riic-grid` is:
```css
display: grid;
grid-auto-rows: 64px;
gap: 3px;
width: max-content;
margin: 0 auto;
```
This is literal `source/js/riic-layout.js:gridTemplateColumns` and `adachurch-style.css:8117-8120`. There are 23 tracks. Elevator tracks are columns 8, 13, and 17. Left and centre elevators occupy rows 1–6. Right elevator occupies rows 2–5. This is `ELEVATORS` and `ELEVATOR_RANGE` in `source/js/riic-layout.js`.

| Tile type | Placement |
|---|---|
| Control Center | row 1, 4×2, right of left elevator |
| Reception | row 2, 3×1, right of centre elevator |
| Dormitory | four fixed 3×1 rooms, left-right rows 3–6 |
| Workshop / Office / Training | fixed 2×1 rooms, right-left rows 3/4/5 |
| Activity Room | six fixed 3×1 rooms, right-right rows 3–5 |
| Production | nine flexible 2×1 left-bank slots |
| Paths | eight 1×1 connectors |
| Elevators | repeated 1×1 infrastructure via `elevatorTiles()` |
Room aspect is intrinsic to grid span. No CSS `aspect-ratio` controls room tiles. The stage has 28px padding and horizontal scrolling. Source: `adachurch-style.css:7982-8007`.

## 6. Component anatomy

### Shared chip family

```html
<button class="chip [active] [rarity-1…rarity-6] [component modifier]">…</button>
```
A base chip is a square translucent 1px rectangle. It uses 8×14px padding, .7rem uppercase 1.2px tracking, low-contrast text, and a shallow inset/drop shadow. Hover changes text alpha .55→.85 and fill .06→.10. `:disabled` is .3 opacity, not-allowed, and pointer-events none. `.active` is opaque accent, on-accent text, and no shadow. Source: `adachurch-style.css:1044-1088`.

| Variant | Size/anatomy | States |
|---|---|---|
| `.class-chip` | 30×30, 4px pad, 16px icon | class color fills active; hover icon scale 1.15 |
| `.riic-mode-card` | 44px high; 16/18px sides; 132px label well | hover .10 glass; active icon rises/label slides |
| mode switch | 40×22, 18px knob | `.on` accent fill; knob +18px |
| report/optimize | chip + 13px icon and 7px gap | idle Optimize pulses |
| quick-save | 44px tool-bar chip, 8px padding | icon-only |
| `.riic-slot-type-btn` | min-height 56px, 17px inset | hover/active brightens 3px product rail |
| stepper button | 26×26 circle, 15px sign | press scale .88; disabled native |
| target/level/tier | ordinary chip | ordinary active fill |
| strategy card | 500:750 art panel | grayscale default; hover/active saturated |
| batch choice | flex:1 connected chips | active selected |
| scope chip | 12px mask, dot wash | active facility-color fill |
| assign slot | full-width column, 16×10px | hover glass fill |
| explain toggle | unboxed uppercase text | hover accent + underline |
| save icon | unboxed, 6px padding, 18px mask | delete hover loss red |
| danger confirmation | red chip | hover white on `#c9433f` |
`chip-group-connected` removes interior borders in connected groups. Source: `adachurch-style.css:7869-7943, 8384-8446, 9140-9338`.

### Room tile

```html
<button class="riic-tile riic-tile-animate-in [riic-tile-empty] [riic-tile-unbuilt]"
 data-slot-id="…" data-facility-type="…">
  <span class="riic-tile-room-clip">
    <span class="riic-tile-room-body[-2x1|-3x1|-4x2]"></span>
    <span class="riic-tile-room-grid"></span>
    <span class="riic-tile-room-accent"></span>
    <span class="riic-tile-room-icon[-plain]"></span>
  </span>
  <span class="riic-tile-info">room name + level pips</span>
  <span class="riic-tile-ops">portrait chips</span>
</button>
```
The root is clipped, square, transparent, 1px white .075, and padded 2px. Eight 8px gradient corner ticks make the blueprint language. Buttons transition border/background in .12s ease. Hover uses white .4 border and accent .08 fill. `.riic-tile-empty` is opacity .6. `.riic-tile-unbuilt` is opacity .55, dashed, saturate(.65). Its unbuilt label is .68em/600 uppercase. Source: `adachurch-style.css:8121-8152`.
The body is `#323232`. The internal grid texture is 70×70px at .35 opacity. Room art is mask-based. Production accents are Trading `#38c9fe`, Factory `#fec904`, Power `#c3ff43`. Facility silhouettes are white .075. Source: `adachurch-style.css:8186-8313`. Room names are 12px/700 condensed white. Pips use 1px gaps and facility-specific colors.
Control Center replaces ordinary metadata with `.riic-cc-badge`, brackets, stripe icon, and an Orbitron version row. DOM order is from `views__base-builder.js:Ei, Ai`.

### Elevator and path tiles

Elevators are `.riic-tile.riic-tile-elevator`. Paths are `.riic-tile.riic-tile-path`. Both overlay a full-cell SVG over the same corner-tick grid. They are infrastructure, not interactive buttons. They have no hover, selection, or disabled state. Source: `adachurch-style.css:8153-8184` and `source/js/riic-layout.js:elevatorTiles`.

### Operator portrait chip

```html
<span class="riic-tile-op-chip"><img src="/api/image/<id>"></span>
```
Chips sit absolute bottom/right 6px in a 1px-gap row. They are exactly 16.1px square. They have 1px white .65 border. Portraits use cover and `object-position:50% 15%`. They enter from scale .7 with `riic-op-chip-in .2s cubic-bezier(.2,0,0,1)`. Fallback is accent/on-accent, 7px/700. Source: `adachurch-style.css:8449-8473` and `views__base-builder.js:Ai`.

### Anchored slot popover

```html
<div id="riic-slot-menu" class="[open] [riic-tile-mode]">
  <div class="riic-slot-menu-types">type buttons</div>
  <div class="riic-slot-menu-level">minus / value / plus</div>
  <div class="riic-strategy-row">strategy cards</div>
  <div class="riic-slot-menu-ops">assigned controls and operators</div>
</div>
```
The JavaScript anchors it to the clicked tile (`views__base-builder.js:nt`). It is 300px wide, minimum 180px, max viewport minus 20px, padded 12px. Initial state is opacity 0, Y -6px, scale .97, top-left origin. `.open` restores it. `.riic-tile-mode` widens it to 350px. Source: `adachurch-style.css:8371-8383`. Assignment list rows use 44px portraits, 8×10px body padding, and a 28px charcoal remove column.
Hovering remove turns it loss red. `.riic-resting-op` is .72 opacity, dashed, and desaturated. Tile assignment is a wrapping 56×56 grid with 8px gaps. The remove square reveals only on hover/focus. The list/tile switch buttons are 22px, accent-filled when active. Source: `adachurch-style.css:8491-8552`.

### Modal shell

```html
<div id="riic-*-modal" class="open">
  <div id="riic-*-panel">close button + body</div>
</div>
```
All RIIC shells are fixed inset flex centres with 24px outer padding. They use `rgba(4,4,4,var(--modal-backdrop-alpha))`, 12px blur, z-index 100, initial opacity 0, and .2s ease fade. `.open` enables pointer events. Panels scale .97→1 in .22s cubic-bezier(.2,0,0,1).

| Panel | Max width | Max height | Padding |
|---|---:|---:|---:|
| Operator picker | 560px | 78vh | 24px 26px |
| Suggest setup | 660px | 82vh | 24px 26px |
| Save/load | 560px | 82vh | 24px 26px |
| Account facts | 460px | none stated | 24px 26px |
| Confirm | 380px | none stated | 22px 24px |
| Report | 672px | 86vh | 24px 26px |
| Report compare | 1220px | 86vh | 24px 18px |
Account facts and Confirm raise z-index to 110. Source: `adachurch-style.css:8588-8610, 8682-8704, 8775-8832, 9000-9025`.

### Level stepper

`.riic-slot-menu-level` is a centred row with 16px gap, 10×8px padding, glass .04 fill, and .08 border. The two 26px circular chip buttons flank a 64px-minimum middle column. The middle stacks labels at 4px gap. Value is 11px tracked .5px. Number is 13px/700. Max is muted. Press scales .88. Unavailable minimum/maximum controls use native disabled state. `.riic-slot-menu-level-unbuilt` mutes the value.
Source: `adachurch-style.css:8426-8447` and `views__base-builder.js:et`.

### Strategy art cards

Level-3 Trading Post Build mode renders two `.riic-strategy-btn` cards. They are equal flex columns with 500:750 aspect ratio. They have no radius, a 1px white .1 border, and start `grayscale(.85) brightness(.65)`. Hover and active restore saturation. Active adds brightness 1.05, white .45 border, and .2 white inset keyline. SVG facets transition opacity/scale in .18s. Highlighted facets scale 1.03.
Source: `adachurch-style.css:9140-9188`, `views__base-builder.js:et`, and `riic-layout.js:TRADING_STRATEGIES`.

### Operator picker row

```html
<button class="riic-op-picker-row [riic-op-picker-row-match]">
  <img class="riic-op-picker-portrait fade-img">
  <span class="riic-op-picker-body">
    <span class="riic-op-picker-head">name + ROOM MATCH badge</span>
    skill tags and prose
  </span>
</button>
```
Rows are top-aligned flex with 10px gap and 10×12px padding. Resting fill is glass .03 and border .08. Hover adds accent .08. Room match adds accent .35 border. Portrait is 44px with standard 1.5px white keyline. The badge is 8px/700 uppercase, 3×7px, accent-filled, fully pill-shaped. Elsewhere is amber 9px/700 pill. Source: `adachurch-style.css:8611-8646` and `views__base-builder.js:dt`.

### Proposal review row

```html
<label class="riic-suggest-card" data-facility-type="…">
  <img class="riic-suggest-card-bg-icon">
  <div class="riic-suggest-card-left">room name, level pips, target</div>
  <div class="riic-suggest-card-mid">operator slots and warnings</div>
  <div class="riic-suggest-card-right"><input class="riic-suggest-row-check"></div>
</label>
```
Rows are clickable flex cards with .04 fill and .08 border. They enter with a staggered .3s fade-up. Hover tints border with accent .3. Left is minimum 138px with 12×14px padding. Middle flexes with 10×14px padding. Right is a 38px checkbox column. Trading/Factory/Power type colors tint subtitle, pips, and right-column background. Portrait slots are 44px with 8px gaps and pop from scale .85.
Empty slots receive a 1px diagonal slash. Leaving/pulling text is loss red. Source: `adachurch-style.css:8898-8998` and `views__base-builder.js:vt`.

### KPI tile

`.riic-yield-row` wraps KPI cards at 10px gaps. Each `.riic-yield-tile` flexes from a 120px minimum. It uses .04 glass, .08 border, a 2px top rule from `--yield-accent`, and 12×14px padding. Value is 21px/700/tabular. Label is muted 9.5px/700 uppercase. There is no hover, active, disabled, or error state. Source: `adachurch-style.css:8723-8736`.

### Facility result card

```html
<div class="riic-facility-card" style="--facility-accent:…">
  optional ghost art
  <div class="riic-facility-card-head">icon + name/subtitle</div>
  <div class="riic-facility-card-chart">SVG or empty state</div>
  <div class="riic-facility-card-foot">hero + idle</div>
</div>
```
Cards auto-fill from 220px at 10px gaps. They are padded 12×14×10px. They use .04 fill, .08 border, overflow hidden, and .28s fade-up. Hover changes border to facility accent .35. Ghost art is 108px at top/right -14px and opacity .1. Icon is 20px. Chart is 68px high. Name is 12px/700. Subtitle is 9.5px/600 facility color. Hero strong is 15px/700. Idle is 9.5px/600 at foreground .4.
Source: `adachurch-style.css:8738-8769` and `views__base-builder.js:ne`.

### Morale card

Morale groups are `.riic-morale-section`. Header: 13px facility icon, uppercase 10.5px/700 title, count aligned right, .08 divider. `.riic-morale-mini-grid` auto-fills `minmax(200px,1fr)` at 8px gap. Cards are 8×10px padded flex rows with .04 fill, .08 border, 30px portrait, 11px/700 name, muted 9px slot, SVG, and 12px tabular ending value. Avatar fades from 0 to 1 in .2s upon `.loaded`.
`.riic-morale-mini-card-depleted` has #ff6b6b .3 border and red value. Source: `adachurch-style.css:8750-8785` and `views__base-builder.js:ce`.

### Events row

```html
<div class="riic-event-row riic-event-row-<type>">
  <span class="riic-event-time">…</span>
  <span class="riic-event-dot"></span>
  <span class="riic-event-label">…</span>
</div>
```
The log is vertically scrollable and capped at 220px. Rows have 7×2px padding, 9px gap, and 11.5px type. Following rows receive .05 white divider. Time is a 76px 10.5px muted tabular column. The dot is 6px round: accent default, red morale, green training, violet swap. Label is 500 foreground. Source: `adachurch-style.css:8787-8801` and `views__base-builder.js:de`.

### Report line and disclosure

Report section header has a 3×16px colored bar, 18px mask icon, and condensed 13px uppercase title. `.riic-report-row` has 8px vertical padding and .05 divider. Name is 12px/600. Hint is 10px muted. Full badge is 9.5px; warning full badge is #ff6b6b. Items below are 20px item-icon flex rows, 11px text/rate, with bold total behind .08 rule. The disclosure is `.riic-explain-toggle`.
Its rows have a 12px status, flexible 11px name, and right 11px/600 value. Counted status is gain. `.riic-explain-row-uncounted` mutes all three. Total gets 12/10px top spacing/rule and a 15px accent result. Footnote is 10px/1.5. Source: `adachurch-style.css:9044-9138` and `views__base-builder.js:It`.

### Compare three-column diff

`.riic-report-compare-grid` is `1fr 168px 1fr` with 12px gap. The outside columns are report cards. The centre is `.riic-report-diff-card`. The layout picker is 42px high with 16px horizontal padding and 10px/1px tracking. Middle title is condensed 12px/700 uppercase. Rows use 8px vertical padding. Labels are 10px. Values are 15px/700/tabular. Use `.riic-report-diff-gain`, `-loss`, and `-flat`.
Source: `adachurch-style.css:9027-9043` and compare markup in `views__base-builder.js`.

## 7. Iconography and imagery

Facility URLs come from:
```js
facilityIconUrl(type) => `assets/riic/\${FACILITY_TYPES[type].icon}.svg`
```
This is `source/js/riic-layout.js:facilityIconUrl`. Names are control_center, reception_room, dormitory, workshop, office, training_room, activity_room, trading_post, factory, and power_plant. Facility pictograms are primarily CSS masks. Their common sizes are 20px facility card, 18px report section, 13px morale group, and enormous low-opacity tile/report decoration. Operators use `/api/image/<operator-id>`.
Item images use `/api/item-image/<item-id>`. Portrait crop is consistently cover at `50% 15%`.

| Context | Image size |
|---|---:|
| Tile operator chip | 16.1px |
| Morale avatar | 30px |
| Picker/list/proposal portrait | 44px |
| Assignment tile | 56px |
| Target item | 18px |
| Report item | 20px |
| Daily-yield item | 22px |
| Ghost facility background | 108px |
Source: `views__base-builder.js:Ai, et, vt, ne` and `adachurch-style.css:8024-8028, 8449-8468, 8494-8498, 8531-8533, 8631-8635`. Direct art also comes from `assets/riic/` and `assets/system/morale.svg`. Use masks and CSS color rather than baked-color icons where the source does.

## 8. Motion

### Tokens and accessibility

`--ease-standard` is `cubic-bezier(0.2,0,0,1)`. `--dur-fast` is `.14s`. `--dur-medium` is `.22s`. `--dur-slow` is `.32s`. Source: `adachurch-style.css:42-45`. Reduced motion disables RIIC optimize pulse, tile entry, operator-chip entry, stripe animation, and selected batch/tally transitions. It does not globally remove every transition. Reproduce the literal selective behavior.

### Base-specific motion inventory

| Trigger | Motion | Duration/easing |
|---|---|---|
| Mode hover | background | .15s ease |
| Mode active | icon rises, label slides | .22/.26s cubic |
| Mode switch | track color, knob +18px | .18s ease / cubic |
| Idle Optimize | scale 1→2.2 + fade | 1.6s ease-out infinite |
| Tally/batch | fade + Y -3→0 | .2/.22s, 30ms delay |
| Stage entry | fade | .3s ease, 160ms delay |
| Tile entry | Y -10 + scale .92→1 | .42s cubic |
| Build stripes | bg -96px→0 | .32s cubic |
| Build label | fade + Y 10→0 | .26/.28s |
| Tile hover | border/background | .12s ease |
| Slot menu | fade + Y -6/scale .97 | .16/.18s |
| Stepper press | scale .88 | .1s ease |
| Tile portrait | scale .7→1 | .2s cubic |
| Assignment controls | color/fill/reveal | .12–.14s |
| Modal | fade / panel scale | .2s / .22s |
| Simulate disclosure | grid 0fr→1fr | .28s cubic |
| Chevron | rotate 180° | .24/.22s |
| Facility card | fade-up | .28s cubic |
| Morale avatar | opacity | .2s ease |
| Proposal card | fade-up, stagger | .3s cubic |
| Proposal op | scale .85→1 | .26s cubic |
| Strategy facets | opacity/scale | .18s |
| Scope chip | fill/border/dots | .14s ease |
| Report card/header | fade-up | .26/.22s cubic |
| Explanation rule | scaleX | .22s cubic |
Named RIIC keyframes:
- `riic-optimize-pulse`: opacity .55→0, scale 1→2.2.
- `riic-tile-drop-in`: opacity 0→1, Y -10→0, scale .92→1.
- `riic-stripe-rack-in`: background -96px→0.
- `riic-op-chip-in`: opacity 0→1, scale .7→1.
- `riic-op-pop-in`: opacity 0→1, scale .85→1.
Generic RIIC-used keyframes:
- `acc-fade-up`: opacity 0/Y -8→normal.
- `acc-fade-in`: opacity 0→1.
Sources: `adachurch-style.css:1542-1543, 7919, 8000, 8069, 8457, 8922`.

### Whole stylesheet keyframe inventory

The stylesheet also declares non-base keyframes:
`bg-photo-drift`, `bg-scan-sweep`, `bg-glow-breathe`, `boot-mark-pulse`, `boot-bars-fill`, `boot-bars-scroll`, `page-kicker-in`, `page-text-in`, `page-rule-draw`, `ptc-outline`, `ptc-fill`, `page-ghost-in`, `op-card-in`, `chip-pulse`, `acc-pop-in`, `acc-ring-draw`, `acc-slide-in-right`, `acc-crystal-glimmer`, `acc-crystal-drift`, `acc-crystal-facet-flash`, `acc-spin`, `acc-sanity-pulse`, `music-card-in`, `music-row-in`, `mp-vinyl-spin`, `mp-spin`, `mp-like-pop`, `mp-like-ring`, `craft-node-in`, `goalStarPopIn`, `goalTilePopIn`, `stage-row-pulse`, `movement-header-in`, `movement-divider-in`, `ticket-progress-in`, `ep-row-in`, `auto-tri-chase`, `avg-now-playing-pulse`, `pack-card-in`, `pcm-ring-draw`, `cal-dot-pulse`, `gantt-axis-in`, `gantt-row-label-in`, `gantt-bar-grow`, `gantt-cutout-in`, `cal-est-pulse`, and `admin-modal-in`.
They belong to other site modules. Their exhaustive declaration locations are `adachurch-style.css:226-10292`.

## 9. Data visualization

Facility sparkline SVG is generated in `views__base-builder.js:ee`. It lives inside a 68px `.riic-facility-card-chart`. Time maps horizontally to percentage of duration. Value maps vertically to `maxY` with 8% headroom. Call-site colors are Factory `#ffca08`, Trading `#55caf5`, Dormitory `#99c144`. It carries no axes. It carries no legend. It carries no point labels. It carries no tooltip.
The nearby subtitle and hero total provide meaning. CSS establishes the card and height; JS establishes plot geometry. Morale uses one inline SVG per mini card. It has an internal .08 foreground, 1px non-scaling gridline class `.riic-morale-mini-gridline`. It likewise has no axes, legend, or tooltip. The operator name, room, and end `current/max` are its labels.
Sources: `views__base-builder.js:ee, ce` and `adachurch-style.css:8766-8783`.

## 10. Responsive behavior

| Query | Exact effect |
|---|---|
| `prefers-reduced-motion:reduce` | Disables selected motions described above |
| `max-width:900px` | Compare report becomes one column; diff moves order 3 |
| `max-width:760px` | Generic calendar/event module only; no RIIC selector |
| `max-width:1150px` or `max-aspect-ratio:4/5` | Other module only; no RIIC selector |
| `max-width:720px` | Other module only; no RIIC selector |
| `max-width:860px` | Admin/home module only; no RIIC selector |
There is no Base Builder-specific mobile reflow in supplied CSS. The floorplan remains `width:max-content` inside an `overflow-x:auto` stage. Narrow layouts scroll the canonical 23-track plan horizontally. They do not shrink or stack it. Modals cap at 100% width and retain 24px outer padding. Slot popover caps at `calc(100vw - 20px)`. Source: `adachurch-style.css:7982-7986, 8371-8378, 9039-9043`.

## 11. Not recoverable from CSS

- Exact appearance, crop, and art direction of SVG/WebP assets cannot be recovered
  from CSS text.
- Browser font rasterization and exact screenshot content lengths are not CSS facts.
- Anchor collision/flip behavior belongs to JavaScript placement `nt`, not CSS.
- Facility SVG stroke/fill/path algorithm belongs to `views__base-builder.js:ee`.
- CSS does not define chart tooltips; the JS template contains none, so do not add one.
- The supplied screenshot captions identify composition, not pixel measurements.

## 12. What is worth stealing and what is not

Steal the contrast discipline. Steal the 64px/3px blueprint grid. Steal clipped facility masks, quiet borders, one strong accent, colored production rails, portrait packing, and the “tiny label + tabular number” hierarchy. The strongest decision is keeping facility color to rules, icons, selected controls, and output accents rather than flooding cards. Do not copy all the noise.
The huge ghost title, permanently animated backdrop, and competing decorative layers would reduce clarity in a less game-specific product. The 7–9px microtext is also too small for general-purpose interfaces. Keep the precision and structural confidence. Relax the theatrics and microtext where accessibility or information volume requires it.
