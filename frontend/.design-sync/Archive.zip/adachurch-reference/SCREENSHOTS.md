# Screenshot index — Closure's Toolbox Base Builder

Captured 2026-08-15 from the live tool at `tools.adachurch.com/#/base`, logged in,
viewport 1500×716. Order follows the real user flow: empty base → configure → assign →
optimize → review.

| # | File | What it shows |
|---|---|---|
| 01 | `01-main-empty-top.jpg` | Landing state. Page header, the action bar (Building Mode toggle, Report, Optimize — Optimize is disabled here), base name field, Single Form toggle, New / quick-save / Save-Load, and the power + ambience counters. Grid begins below. |
| 02 | `02-grid-and-daily-yield.jpg` | The full base grid: Control Center with its level arrows, Reception, two elevator spines, four Dormitories, Workshop / Office / Training, six Activity Rooms, nine production slots. Daily Yield panel docked underneath. |
| 03 | `03-simulate-output-controls.jpg` | Deep Dive expanded. Simulate Output section: 1D / 3D / 7D window chips, "How often do you check in?" cadence chips (Once a day / Twice a day / 3× a day / Intensive), Run. |
| 04 | `04-results-empty-state.jpg` | Empty state after simulating an unstaffed base — "Not enough data" per facility card, "No operators assigned to simulate", "No events." Worth copying: the empty state is per-card, not one global blank slate. |
| 05 | `05-save-load-modal.jpg` | Save / Load modal. Five fixed slots per account, each row with load / overwrite / delete icon actions and a "Currently Loaded" badge. |
| 06 | `06-build-slot-popover.jpg` | Building Mode slot editor, anchored to the clicked tile: facility type list (Trading Post / Factory / Power Plant, with "(max 3)" and disabled states), level stepper (− Lv 3 / 3 +), Trading Strategy as two large art cards (Business / Mining), Clear Slot. |
| 07 | `07-operators-mode-formations.jpg` | Operators Mode. The mode toggle relabels itself, a Form A / Form B switch appears with the status line "Viewing & editing Formation A", and Optimize becomes enabled. |
| 08 | `08-room-assign-panel.jpg` | Room staffing popover: "ASSIGNED (0 / 3) · FORMATION A", a view-density switch, and the Assign affordance. |
| 09 | `09-operator-picker.jpg` | Operator picker modal. Search field, then one card per operator: portrait, name, a "ROOM MATCH" badge, and every relevant base skill spelled out in full prose with the numbers highlighted. |
| 10 | `10-optimize-suggest-setup.jpg` | **The core screen.** "Suggest Setup": explanatory paragraph, "Optimize which rooms" chips colour-coded per facility type (only built types appear), Balance Both Formations / This Formation Only (A), cadence chips, an account-facts row (influence / territory / extra recruit slots), Run. |
| 11 | `11-optimize-morale-warning.jpg` | Post-run warning surfaced above the proposal: "1 operator will run low on Morale swapping twice a day", naming the operator and telling the user which control changes it. |
| 12 | `12-optimize-proposal-review.jpg` | Proposal review, grouped by facility type. One row per room: room name + level pips, its configured target/strategy, the proposed operator portraits in slot order, and a per-room accept checkbox. |
| 13 | `13-optimize-proposal-dorms.jpg` | Same review, further down — Formation B rooms and five-slot Dormitories. |
| 14 | `14-optimize-apply-discard.jpg` | End of the proposal: single-operator rooms (Office, Power Plants, Training) and the Apply Selected / Discard pair. Nothing is applied until this point. |
| 15 | `15-grid-populated.jpg` | The grid after applying — operator portrait chips packed into each room tile. This is the real density the layout has to survive. |
| 16 | `16-riic-report.jpg` | R.I.I.C Report modal. Per-facility projected performance: productivity %, "Full in 1.34d", per-hour rates, and a "How this is calculated" disclosure on every line. Compare button in the header. |
| 17 | `17-riic-report-buff-breakdown.jpg` | A disclosure expanded: every contributing operator buff by name with its individual %, summed to Final productivity, plus an honest footnote about what the number excludes. |
| 18 | `18-riic-report-dormitory.jpg` | Dormitory section of the report: base regen / ambience bonus / operator bonus / total, per room. |
| 19 | `19-riic-report-compare.jpg` | Compare mode: two layout pickers side by side with a Difference column between them showing ± deltas per metric. |
| 20 | `20-daily-yield-populated.jpg` | Daily Yield with a staffed base — LMD / Pure Gold / Battle Records per day, plus a red "−1826.1 lost if claimed only once" annotation and a "login before <time>" deadline. |
| 21 | `21-simulate-7d-kpis.jpg` | 7-day simulation results: four KPI tiles (Pure Gold, Battle Records, LMD, Morale Recovered) with type-coloured top rules. |
| 22 | `22-simulate-facility-cards.jpg` | Output by facility — one card per room with a cumulative sparkline, total produced, and efficiency in the subtitle. |
| 23 | `23-morale-over-time.jpg` | Morale over time: every assigned operator as a card with a morale sparkline and current/max value, grouped by facility with per-group counts. ~60 cards at once — the densest screen in the tool. |
| 24 | `24-events-timeline.jpg` | Events timeline: timestamped formation swaps and morale-depletion events, colour-dotted by kind. |
