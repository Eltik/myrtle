# Live API captures — 2026-08-15

Captured by calling the endpoints directly from the authenticated page context. These are
real responses from `tools.adachurch.com`, not inferred shapes. Account: Discord user
`Eltik`, roster of **347 operators**, `drone_capacity: null`.

## Endpoint inventory (from `js/views/base-builder.js` + `js/app.js`)

| Method | Path | Request body | Purpose |
|---|---|---|---|
| GET | `/api/base-layouts` | — | `{layouts:[{layout_id,name,...}]}`, 5 slots max per account |
| GET | `/api/base-layouts/{id}` | — | `{layout_id,name,dual_batch,updated_at,slots}` |
| POST | `/api/base-layouts` | `{slots, slot_id}` | save/overwrite a layout slot |
| GET | `/api/base-layouts/roster` | — | `{operators:[...], drone_capacity}` |
| GET/PATCH | `/api/base-layouts/advanced-inputs` | `{wang_influence_ge_territory, recruit_slot_count}` | persisted account facts |
| POST | `/api/base-layouts/optimize` | `{slots, optimize_facility_types[], dual_batch?, batch_swap_hours?, exclude_char_ids?}` | assignment search |
| POST | `/api/base-layouts/report` | `{slots, yield_hours_elapsed?, login_interval_hours?}` | steady-state rates |
| POST | `/api/base-layouts/simulate` | `{slots, dual_batch, batch_swap_hours, duration_hours, start_batch}` | time-stepped projection |
| POST | `/api/base-layouts/explain-slot` | `{slots, slot_id}` | per-room buff attribution |
| POST | `/api/base-layouts/synergies` | `{slots}` | `{synergies:{}}` — conditional-buff hints |
| GET | `/api/me` | — | `{user_id, username, avatar_url, is_admin}` |

## Slot object (the universal payload unit)

```json
{"facility_type":"factory","level":3,"char_ids":["char_225_haak"],"char_ids_b":[],"target":"gold"}
```

Conditional fields, added only for the matching `facility_type`:
`trading_post → strategy`, `factory → target`, `dormitory → ambience`,
`training_room → target_level`, `workshop → target_tier`.
Training rooms carry `{trainee, trainer}` objects rather than a flat `char_ids` list.
`char_ids_b` is the Formation B roster for the same slot.

Slot ids are stable strings: `control_center`, `reception_room`, `office`, `workshop`,
`training_room`, `dorm_a`…`dorm_d`, `production_1`…`production_9`, `activity_a`…`activity_f`.

## Roster operator

```json
{"id":"aak","name":"Aak","rarity":6,"char_id":"char_225_haak","evolve_phase":"...","level":...,
 "base_skills":[{"buff_id":"control_clue_cost[000]","name":"Neuroticism","icon":"bskill_ctrl_c_wt",
   "description":"When this Operator is assigned to the Control Center, <@cc.kw>increases</> ...",
   "room_type":"CONTROL","phase":"PHASE_0","level":1}]}
```

Descriptions carry inline rich-text markup (`<@cc.kw>`, `<@cc.vdown>`, `<@cc.vup>`) rendered
by `js/rich-text.js`. `room_type` values are the game's internal enum: `CONTROL`,
`MANUFACTURE`, `TRADING`, `DORMITORY`, `MEETING`, `WORKSHOP`, `HIRE`, `TRAINING`, `POWER`.

## optimize — response

```json
{"assignment":{"control_center":["char_4132_ascln", ...],"production_1":[...]},
 "score":552.0249999999999,
 "per_slot":{"control_center":49.95,"production_1":73.5,"dorm_a":1.25,"activity_a":0.0, ...}}
```

Only three keys — no rationale, no alternatives, no confidence. Dual mode returns
`assignment_a` / `assignment_b` instead of `assignment`.

**Observed per-slot score weights** (all-facility run, 347-operator roster):
production slots 63–74 · control_center 49.95 · workshop 25 · reception_room 18.25 ·
training_room 15 · office 12.375 · dormitories 1.25–1.6 · activity rooms 0.0.
Total 552.02 for an all-facility run vs 476.09 for the production-only run on the same account —
i.e. non-production rooms are scored, but at roughly an order of magnitude lower weight than
production, and activity rooms score exactly zero.

## report — response

Four keys: `factory[]`, `trading_post[]`, `dormitory[]`, `yield_login_summary`.

```json
factory[i]      = {slot_id, level, target:"gold"|"exp", status:"ok", productivity_pct:105,
                   total_rate_per_hour:1.708, capacity:54, yield_capacity:54, hours_to_full:31.61,
                   items:[{item_id:"3003", name:"Pure Gold", rate_per_hour:1.708}]}
trading_post[i] = {slot_id, level, strategy:"gold", capacity:13, capacity_base:10,
                   order_limit_bonus:3, efficiency_pct:138, effective_strategy:"gold",
                   total_rate_per_hour:1047.826, orders_per_hour:0.5239,
                   items:[{item_id:"4001", name:"LMD", rate_per_hour:1047.826}],
                   yield_capacity:26000, hours_to_full:24.81}
dormitory[i]    = {slot_id, level:5, ambience:5000, base_morale_per_hour:2,
                   ambience_morale_per_hour:2, operator_morale_per_hour:3, total_morale_per_hour:7}
yield_login_summary = {recommended_login_hours:22.39, bottleneck_slot_id:"production_8",
                   period_hours:12, login_interval_hours:12,
                   daily:[{item_id, name, on_time_amount, once_daily_amount, loss_amount}]}
```

Note what the report does **not** cover: power plants, control center, office, workshop,
training room and activity rooms have no report section at all.

## explain-slot — response

```json
{"slot_id":"production_1","room_type":"MANUFACTURE","primary_metric":"productivity",
 "contributors":[{"char_id":"char_385_finlpp","buff_id":"manu_prod_spd&trade[000]",
   "source_slot_id":"production_1","metric":"productivity_gold","value":40,"counted":true,
   "char_name":"Purestream","skill_name":"Renewable Energy"}, ...],
 "total":105}
```

**The important mechanic:** `source_slot_id` is frequently a *different room* than the one
being explained. Explaining a Trading Post returned contributors seated in the Control
Center (`{char_id:"char_4132_ascln", buff_id:"control_tra_spd[030]", source_slot_id:"control_center",
metric:"trading_efficiency", value:7}`). Buffs propagate across rooms, so a room's number is
not a function of its own occupants alone.

`counted: true/false` marks clauses that were evaluated but did not apply — the data model
supports showing rejected buffs, though the UI only renders counted ones.

Control Center returns `primary_metric: null`, `contributors: []`, `total: 0` — it has no
scalar output metric even though the optimizer scores it at ~50.

## simulate — response

Six keys:

```json
{"duration_hours":24,
 "totals":{"factory":[{slot_id,target,total_amount:41,productive_hours:24,idle_hours:0}],
           "trading_post":[{slot_id,efficiency_pct:138,strategy,item_id,item_name,
                            total_amount:25147.83,productive_hours,idle_hours}],
           "dormitory":[{slot_id,total_recovery:96}]},
 "output_timeline":{"production_1":[{t:0,...}, ...]},
 "morale_timeline":{"char_4132_ascln":[{t:0,morale:24,slot_id:"control_center"},{t:24,...}]},
 "char_home_slot":{"char_4132_ascln":"control_center"},
 "events":[{t:8.889,type:"morale_depleted",slot_id:"reception_room",
            char_id:"char_4036_forcer",detail:"Ran out of Morale in Meeting"}]}
```

`morale_timeline` is per operator, not per room — which is why the UI can draw ~60
individual sparklines. `events` is the only place formation swaps and morale exhaustion are
reported as discrete facts.

## synergies

Returned `{"synergies":{}}` for every layout tried, including a fully optimized one. The UI
calls it on opening a room popover in assign mode and merges the result into the operator
cards, so it appears to surface conditional/presence-gated buffs only when the layout
actually contains such a pair.
