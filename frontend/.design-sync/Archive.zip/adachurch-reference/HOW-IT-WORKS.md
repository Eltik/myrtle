# How Closure's Toolbox RIIC base optimizer works

## 1. What the system is

Closure's Toolbox is a planner for Arknights' RIIC base. RIIC is a fixed building with rooms of different types. The player chooses which room each available operator occupies. Operators bring “base skills,” rather than combat skills.

Those skills improve manufacturing, trading, morale recovery, clue search, recruitment, training, workshop byproducts, power/drone recovery, or another room. The tool accepts a player-specific room layout and synced operator roster. It can recommend personnel assignments, show a steady-state production report, and simulate a finite period in which morale runs out and formations rotate.

It is not a layout builder in the optimization sense. It never chooses whether a production slot should be a Factory, Trading Post, or Power Plant. It scores and assigns within the layout supplied by the user. `PDF §7`; `js/views__base-builder.js` The difficult part is interaction. An operator can buff all Trading Posts while seated in Control Center.

Another can scale with the number of a faction in the base. A third can suppress co-workers’ contribution to a metric. Thus, a room’s value is not the sum of its visible occupants. `PDF §3`; `LIVE-API-CAPTURES.md` With `n` eligible operators and `s` assignable slots, a naive search is roughly an ordered, capacity-constrained selection of `s` from `n`, not `n × s` independent decisions.

Roster exclusivity and cross-room effects make independent per-room ranking incorrect. `PDF §7` The author’s stated architecture solves this by parsing every game-text bonus into a generic clause, scoring a complete tentative assignment, then using a greedy-plus-local-search heuristic. It is a strong candidate generator, not a proof of global optimality. `PDF §§1,7,9`

## 2. Domain model

### 2.1 Facility catalogue

These are the actual client enumerations, including internal `facility_type`, game `roomType`, maximum count, power at each level, and staffing capacity at each level. `js/riic-layout.js`

| `facility_type` | Name | category | `roomType` | max count | levels: power | levels: slots |
| --- | --- | --- | --- | ---: | --- | --- |
| `control_center` | Control Center | fixed | `CONTROL` | 1 | `0,0,0,0,0` | `1,2,3,4,5` |
| `reception_room` | Reception Room | fixed | `MEETING` | 1 | `-10,-30,-60` | `2,2,2` |
| `dormitory` | Dormitory | fixed | `DORMITORY` | 4 | `-10,-20,-30,-45,-65` | `5,5,5,5,5` |
| `workshop` | Workshop | fixed | `WORKSHOP` | 1 | `-10,-10,-10` | `1,1,1` |
| `office` | Office | fixed | `HIRE` | 1 | `-10,-30,-60` | `1,1,1` |
| `training_room` | Training Room | fixed | `TRAINING` | 1 | `-10,-30,-60` | `2,2,2` |
| `activity_room` | Activity Room | fixed | `null` | 6 | `0,0,0` | `0,0,0` |
| `trading_post` | Trading Post | flexible | `TRADING` | 5 | `-10,-30,-60` | `1,2,3` |
| `factory` | Factory | flexible | `MANUFACTURE` | 5 | `-10,-30,-60` | `1,2,3` |
| `power_plant` | Power Plant | flexible | `POWER` | 3 | `60,130,270` | `1,1,1` |

`FLEXIBLE_TYPE_IDS` is exactly `['trading_post','factory','power_plant']`. `js/riic-layout.js` `ROOM_SKILL_TAGS` maps game room types to these display identities:

`CONTROL` `#21524f` / `buff_control_center`; `MANUFACTURE` `#f8d746` / `buff_factory`; `TRAINING` `#6d1324` / `buff_training_room`; `POWER` `#99c144` / `buff_power_plant`; `HIRE` `#545454` / `buff_office`; `DORMITORY` `#62caca` / `buff_dormitory`; `TRADING` `#2f70a0` / `buff_trading_post`; `WORKSHOP` `#e4eb4d` / `buff_workshop`; and `MEETING` `#ce6d45` / `buff_reception_room`. `js/riic-layout.js` “Production” slots are the nine mutable left-side locations.

They may contain any flexible type. The remaining non-path locations are fixed type locations. `js/riic-layout.js`

### 2.2 Stable slot identifiers

The client’s stable IDs are: `control_center`, `reception_room`, `office`, `workshop`, and `training_room`. Dormitories are `dorm_a`, `dorm_b`, `dorm_c`, and `dorm_d`. Production locations are `production_1` through `production_9`.

Activity rooms are `activity_a` through `activity_f`. `js/riic-layout.js`; `LIVE-API-CAPTURES.md` The layout grid also has eight `path_*` entries and elevators. They are render-only and are not slot payloads. `js/riic-layout.js`

### 2.3 Per-room configuration

A universal slot payload begins as:

```json
{"facility_type":"factory","level":3,"char_ids":["char_225_haak"],"char_ids_b":[],"target":"gold"}
```

`char_ids` is Formation A in the persisted universal representation. `char_ids_b` is Formation B. For a single-form optimize request, the client sends only the formation being edited as `char_ids`. It sends the other formation's IDs as `exclude_char_ids`, preventing overlap. `js/views__base-builder.js` Conditional fields are:

| Type | field | values / meaning |
| --- | --- | --- |
| `factory` | `target` | `exp`, `gold`, `diamond`, or `asc` |
| `trading_post` | `strategy` | `gold` or `diamond` |
| `dormitory` | `ambience` | numeric ambience total |
| `training_room` | `target_level` | string `1`, `2`, or `3` |
| `workshop` | `target_tier` | `TIER_2`, `TIER_3`, `TIER_4`, or `TIER_5` |

Training differs structurally. Its `char_ids` / `char_ids_b` values are `{trainee,trainer}` objects, not arrays. The UI treats the trainee as arbitrary specialization training input and the trainer as the base-skill holder. `js/views__base-builder.js` Factory targets are Battle Records (`exp`, available level 1), Pure Gold (`gold`, level 1), Originium Shard (`diamond`, level 3), and Dualchip (`asc`, level 3).

Their item IDs by level are respectively `2001,2002,2003`; `3003,3003,3003`; `null,null,3141`; and `null,null,3223`. `js/riic-layout.js` Trading strategies are `gold` / Business Strategy / “LMD-leaning orders”, and `diamond` / Mining Strategy / “Orundum-leaning orders”; both require level 3. `js/riic-layout.js`

### 2.4 Formations, morale, ambience, drones

Dual formation means two disjoint operating rosters intended to be manually swapped at login. It is not an automatic in-game scheduler. The UI explicitly says swaps happen “when you actually log in and do it.” `js/views__base-builder.js` Each operator starts simulation with 24 morale in the visual contract.

The UI renders the final morale as `/24` and marks zero as depleted. `js/views__base-builder.js` Dorm occupants recover morale. The report decomposes recovery into base, ambience, and operator bonuses. The captured level-5, ambience-5000 example is `2 + 2 + 3 = 7` morale/hour. `LIVE-API-CAPTURES.md` Ambience is a room configuration, not inferred from furniture.

The client sums configured dorm ambience only for display. `js/views__base-builder.js` `drone_capacity` comes from `/api/base-layouts/roster`. The captured account reports `null`; the client displays a drone chip only if non-null. No capture establishes the server’s drone-capacity formula. `LIVE-API-CAPTURES.md`; `js/views__base-builder.js`

### 2.5 Power

`netPower(slots)` sums `FACILITY_TYPES[type].power[level - 1]` for every configured facility. Positive Power Plants offset negative consumers. The display is generated-power minus net-power over generated-power; negative net power is styled short. `js/riic-layout.js`; `js/views__base-builder.js` This is client-side validation/display only.

The captures do not establish whether optimizer, report, or simulation rejects a power-deficient layout. (inferred)

## 3. The clause engine

### 3.1 Why clauses exist

Raw Arknights descriptions are prose with rich-text markup. The roster endpoint supplies `buff_id`, name, description, `room_type`, phase, and level. The browser uses those fields to select the currently active skill for presentation only. `LIVE-API-CAPTURES.md`; `js/views__base-builder.js` The algorithm reference says parsing prose into clauses is upstream and data-source-specific.

The scorer consumes only normalized clauses. `PDF §1` The normalized row is:

| Field | type | meaning |
| --- | --- | --- |
| `owner_room_type` | string | room type in which the operator must sit for activation |
| `metric` | string | affected stat, such as `productivity`, `trading_efficiency`, or `capacity` |
| `target_scope` | enum | resolver shape |
| `value` | number | signed per-unit magnitude |
| `scale_tag` | optional string | generic tag, entity ID, faction, or account-stat key |
| `scale_scope` | optional string | count/check scope: room type, `BASE`, or owner room |
| `scale_cap` | optional number | cap or threshold |

`value` is already signed in the metric’s native direction. Metric polarity is applied later, once, so lower-is-better metrics can still maximize score. `PDF §§2,4` `scale_tag` and `scale_scope` deliberately remain untyped strings. One schema can therefore represent named operators, factions, roster-wide tags, and account facts. `PDF §2`

### 3.2 Target-scope vocabulary and examples

The following is the full fixed taxonomy in the author’s reference. `PDF §3`

| `target_scope` | generic resolution | concrete Arknights-shaped example |
| --- | --- | --- |
| `self` | flat contribution to owner room | a Factory operator’s `+25%` productivity |
| `room_type_global` | fan out once per built target room | Control Center operator gives `+7%` Trading efficiency to every Trading Post |
| `scaling_count` | `value × matching count` | Fang the Fire-Sharpened: productivity per A1 operator in scope |
| `scaling_level_self` | `value × owner room level` | a skill granting per level of its own room |
| `scaling_level_sum` | `value × sum(levels of target room type)` | Engineering-type bonus using total facility levels |
| `scaling_room_count` | `value × built-room count` | Purestream’s Factory productivity scales with Trading Post count |
| `requires_char` | value iff specific operator present | Tragodia/Ms. Christine same-Factory gate |
| `requires_tag` | value iff matching tagged entity present | Warmy presence enables Alanna’s effect |
| `requires_absent_tag` | value iff no match present | Vermeil’s effect when Bubble is absent |
| `requires_count_tag` | value iff count reaches `scale_cap` | faction/team threshold gate |
| `requires_level` | value iff own configuration matches | Factory bonus only for configured Gold/EXP output |
| `requires_account_stat` | value iff persisted account fact matches | Wang’s Influence ≥ Territory condition |
| `resource_convert` | move shared pool into a metric/pool | pool-producing and pool-consuming combo chain |
| `suppresses_others` | zero co-occupants’ metric contribution | a special occupant overriding roommates’ metric |
| `scaling_peer_metric` | scale from roommates’ computed metric | Waai Fu-style copied productivity |

The examples identify the reduction shape, not necessarily the exact shipped clause spelling. Only the PDF is authoritative about these normalized names. `PDF §3` For directly visible older data, `manu_prod_spd&power[020]` is Weedy E2’s `productivity_per_power_plant: 15`, a `scaling_room_count` example. `manu_prod_spd&trade[000]` is Purestream’s cross-room Trading-Post count pattern.

`manu_formula_spd&dorm&lv[000]` contains `productivity_gold_per_dorm_sum: 1`, a `scaling_level_sum` pattern. `prior-art/basemaker-config/skills.js` `manu_prod_spd_variable[000]` records Vermeil’s `productivity_per_total_cap_vermeil: 2`. `manu_prod_spd_variable3[000]` records Bubble’s peer/cap-dependent values. Those demonstrate why simple static per-operator ratings are insufficient. `prior-art/basemaker-config/skills.js`

### 3.3 Resolution prerequisites

Before resolving a clause, the scorer must establish:

* which rooms are built, their types, levels, capacities, and configurations;

* each room’s occupants and each operator’s active clauses;

* roster-wide and room-wide tag/entity counts;

* persisted external facts; and

* metric polarity, weights, and configuration-discount rules. `PDF §§2–4`

An unresolved clause contributes zero. The reference calls this “never guess.” `PDF §9` For configured-output clauses, full value applies when generic or matching target; discounted value applies if the output has not been chosen; and zero applies if a named target conflicts with configuration. The numeric discount is not specified in the supplied sources. `PDF §4`

## 4. Scoring a layout

### 4.1 Forward pass

For every assigned entity and every clause active in its owner room type:

1. resolve ordinary target scopes;

2. multiply raw magnitude by metric polarity and metric weight;

3. add it to total and per-room score; and

4. write it into `ledger[(room, entity)][metric]`. `PDF §5`

The ledger is essential. It retains attribution by operator and metric, which later scopes need to inspect. It is also the natural substrate for an explain endpoint. `PDF §5` Conceptually:

```text
contribution = resolve(clause, room, assignment)
             × polarity(metric)
             × weight(metric)
             × configuration_discount(clause, room)
```

The PDF places configuration adjustment “between raw resolved magnitude and actual contribution.” `PDF §4`

### 4.2 Cross-room attribution

Cross-room effects must be credited to the affected room for `per_slot`, while retaining the caster’s location for explanation. This is observed, not just theoretical. Explaining a Trading Post returned a `trading_efficiency` value of `7` whose `source_slot_id` was `control_center`, with character `char_4132_ascln`. `LIVE-API-CAPTURES.md` An implementation should therefore model at least:

```text
owner slot       = where the operator must be seated
target slot(s)   = where its resolved metric lands
source_slot_id   = owner slot, for explanation
```

Do not compute a room explanation merely from that room’s occupants. `LIVE-API-CAPTURES.md`

### 4.3 Deferred passes

`resource_convert`, `scaling_peer_metric`, and `suppresses_others` defer from the forward pass. `PDF §§3,6` For pools, first collect all producers by pool name.

Then use batched fixed-point relaxation: each round reads the prior pool state, applies all writes together, stops on stability or round limit, then converts settled pools to real metrics once. `PDF §6` For peer scaling, recompute each clause against the current ledger each round. Apply the new contribution minus that clause’s previous contribution, not the entire new amount.

Stop when maximum delta is under a small threshold or the capped iteration count is reached. `PDF §6` Suppression runs strictly last. For each suppression clause, zero every other occupant’s contribution of the affected metric, leaving the suppressor’s own ledger value intact. `PDF §6`

### 4.4 Observed objective weights

One all-facility run with 347 owned operators produced score `552.025`. The same account’s production-only run scored `476.0875`. `LIVE-API-CAPTURES.md`; `fixtures/optimize-252-body.json` Observed per-slot score ranges were:

| slot group | observed score |
| --- | ---: |
| Factory / production | `63–74` (two Power Plants in the 2-5-2 fixture were `5.5`, `5.0`) |
| Control Center | `49.95` |
| Workshop | `25` |
| Reception Room | `18.25` |
| Training Room | `15` |
| Office | `12.375` |
| Dormitories | `1.25–1.6` |
| Activity rooms | `0.0` |

This proves non-production rooms participate in the optimizer objective. It does not expose metric weights, formulae, or a universal room base score. (inferred) The Control Center can score about `49.95` even when `explain-slot` says its primary metric is null, has no contributors, and total `0`. Therefore optimize scoring includes value not exposed by that endpoint. `LIVE-API-CAPTURES.md`

## 5. Assignment search

### 5.1 Stated algorithm

The author specifies a two-stage heuristic. `PDF §7` First, process rooms in a fixed priority order. Outward-effect hub rooms should be first, because their occupants change subsequent room values.

For each open slot, tentatively place every still-available candidate, score the entire layout, keep the best candidate, then remove it from availability. `PDF §7` Second, repeatedly attempt every pairwise swap of already-filled slots. Keep an improving swap; revert every non-improving one.

Stop when an entire sweep has no improvement or pass cap is reached. `PDF §7` The fixed room ordering, tie-break policy, pass limit, and exact candidate filtering are not exposed. They must be chosen by a reimplementation. (inferred)

### 5.2 Constraints visible at the API boundary

`optimize_facility_types` scopes which facility types are eligible for reassignment. The client exposes selection over all facility type IDs, and optimizer output only assigns requested slots. `js/views__base-builder.js`; `fixtures/optimize-252-body.json` Room capacity comes from the table in §2.1.

The client permits no more than that many assigned IDs in a normal room. `js/views__base-builder.js`; `js/riic-layout.js` An operator must not be reused in the assignment.

The PDF says candidates are removed from the shared available pool. `PDF §7` For a one-side optimization while dual mode is active, client-generated `exclude_char_ids` contains all IDs in the opposite formation, including training `trainee` and `trainer` where present.

This makes two formations disjoint even across unoptimized rooms. `js/views__base-builder.js` The server’s behavior for malformed duplicate IDs, unknown IDs, missing rooms, or over-capacity input is not captured. (inferred)

### 5.3 Dual-form search

The PDF’s dual variant drafts interleaved. The currently lower-scoring formation receives the next choice. Both forms draw from one availability pool. `PDF §8` Then it locally refines each form independently.

Finally it tries cross-formation swaps, accepting one that helps the weaker form without meaningfully hurting combined average. `PDF §8` Observed dual response fields are `assignment_a`, `assignment_b`, `score_a`, `score_b`, and `justification`.

The fixture has `428.9875` and `429.975`, then a `holds_up` verdict for a 12-hour swap and 168-hour horizon. `fixtures/optimize-252-dual-body.json` That response corroborates balancing, but does not reveal its tolerance or simulation implementation. (inferred)

## 6. Simulation versus report

### 6.1 Report

`POST /report` is a steady-state rate report. It returns `factory[]`, `trading_post[]`, `dormitory[]`, and `yield_login_summary`. `LIVE-API-CAPTURES.md` It does not report Power Plants, Control Center, Office, Workshop, Training Room, or Activity Rooms. That omission does not mean their buffs are ignored in rate calculation. `LIVE-API-CAPTURES.md` Factory response fields are:

`slot_id`, `level`, `target`, `status`, `productivity_pct`, `total_rate_per_hour`, `capacity`, `yield_capacity`, `hours_to_full`, and `items[]`. An observed Gold example is 105% productivity, 1.708 items/hour, capacity 54, and 31.61 hours to full. `LIVE-API-CAPTURES.md` Trading response fields are:

`slot_id`, `level`, `strategy`, `capacity`, `capacity_base`, `order_limit_bonus`, `efficiency_pct`, `effective_strategy`, `total_rate_per_hour`, `orders_per_hour`, `items[]`, `yield_capacity`, and `hours_to_full`.

The observed Gold example is capacity `13 = 10 + 3`, 138% efficiency, 1047.826 LMD/hour, 0.5239 orders/hour, 26,000 LMD capacity, and 24.81 hours to full. `LIVE-API-CAPTURES.md` The client distinguishes `unconfigured`, `locked`, and `productivity_only` Factory statuses. For `productivity_only`, it displays percent but says exact rate is not exposed by sourced game data. `js/views__base-builder.js`

### 6.2 Simulation

`POST /simulate` is a time-stepped projection. It receives `slots`, `dual_batch`, `batch_swap_hours`, `duration_hours`, and `start_batch`. `LIVE-API-CAPTURES.md`; `fixtures/simulate_payload.json` It returns `duration_hours`, `totals`, `output_timeline`, `morale_timeline`, `char_home_slot`, and `events`. `LIVE-API-CAPTURES.md` `morale_timeline` maps every operator ID to points `{t,morale,slot_id}`.

It is intentionally per operator rather than per room. This supports the UI’s individual morale sparklines. `LIVE-API-CAPTURES.md`; `js/views__base-builder.js` Events include `batch_swap`, `morale_depleted`, `training_complete`, and `fiammetta_swap` labels.

The observed depletion event is at `t:8.889`, in `reception_room`, for `char_4036_forcer`. `LIVE-API-CAPTURES.md`; `js/views__base-builder.js` Factory totals include target, cumulative amount, productive hours, and idle hours. Dorm totals include total recovery.

Trading simulation may include only efficiency/productive/idle hours and an explicit note that it is held steady-state because game order-arrival timing is not exposed. `fixtures/simulate-252.json` Consequently, calling this a discrete order-by-order Trading Post simulation would be incorrect. It is a hybrid time simulation with a steady-state trading approximation. `fixtures/simulate-252.json`

### 6.3 Login loss / bottleneck

`yield_login_summary` is report-side, not the simulation response. It contains `recommended_login_hours`, `bottleneck_slot_id`, `period_hours`, `login_interval_hours`, and `daily[]`. `LIVE-API-CAPTURES.md` Each daily entry has `item_id`, `name`, `on_time_amount`, `once_daily_amount`, and `loss_amount`.

The apparent model compares collection on the specified interval to a once-per-period collection, then identifies the room that fills first. (inferred from field names and UI) The observed summary recommends `22.39` hours and identifies `production_8` with a 12-hour period/input interval. `LIVE-API-CAPTURES.md` The client supplies `yield_hours_elapsed` and `login_interval_hours` only when requested.

It refreshes the default summary after layout edits. `js/views__base-builder.js`

## 7. Game mechanics modelled

### 7.1 Exposed formulas and limits

The report makes these relationships observable:

```text
factory hours_to_full = yield_capacity / total_rate_per_hour
trading hours_to_full = yield_capacity / total_rate_per_hour
trading capacity = capacity_base + order_limit_bonus
dorm total recovery/hour = base + ambience + operator
```

The quoted Factory values satisfy `54 / 1.708 ≈ 31.62` hours. The Trading values satisfy `26000 / 1047.826 ≈ 24.81` hours. `LIVE-API-CAPTURES.md` No source supplies the general base Factory rate, base Factory capacity by level, base Trading order time, or ambience-to-morale formula. Do not manufacture those formulas from one response. (inferred) The older implementation has a separate approximate Trading model:

order probabilities are `[.3,.5,.2]`, `[.15,.3,.55]`, `[.13,.22,.65]`, `[.05,.1,.85]`; four-bar values are `500`, `562.5`, `625` LMD; and two/three/four-bar times are `144`, `210`, `276` minutes. `prior-art/basemaker-config/tp_orders.js` Its baseline TP daily LMD is `10000`, `10110`, `10265` for levels 1–3. `prior-art/basemaker-config/tp_orders.js` Those numbers are prior-art constants, not demonstrated shipped Toolbox formulas.

Treat them as an explanation of older implementation behavior only. `prior-art/basemaker-scripts/core/planner.js`

### 7.2 Metrics the client recognizes

The client maps these metric keys for explanations:

`productivity`, `productivity_gold`, `productivity_exp`, `productivity_diamond`, `trading_efficiency`, `order_limit`, `morale_recovery`, `morale_drain`, `clue_rate`, `drone_speed`, `hr_speed`, `training_speed`, `byproduct_rate`, and `facility_count_bonus`. `js/views__base-builder.js` This is a UI vocabulary, not proof that every key has a nonzero optimizer weight. (inferred) Workshop configuration offers tiers `TIER_2` through `TIER_5` at minimum level 1.

Training configuration offers levels `1`, `2`, and `3` at minimum level 1. `js/riic-layout.js`

## 8. Data contract

### 8.1 Authentication and shell

The SPA fetches `/api/me` at boot and stores user data in `window.ME`. `/base` dynamically loads the base-builder view. `js/app.js`; `js/router.js` All API calls shown use browser `fetch` with JSON `Content-Type` for bodies. No explicit Authorization header appears in the client module; authentication is therefore likely cookie/session based. (inferred) `js/views__base-builder.js`

### 8.2 Persistence endpoints

| method/path | body | response / behavior |
| --- | --- | --- |
| `GET /api/base-layouts` | none | `{layouts:[{layout_id,name,...}]}`; UI says max five |
| `GET /api/base-layouts/{id}` | none | `{layout_id,name,dual_batch,updated_at,slots}` |
| `POST /api/base-layouts` | `{name,slots,dual_batch}` | creates and returns at least `layout_id` |
| `PUT /api/base-layouts/{id}` | `{name,slots,dual_batch}` | overwrites saved layout |
| `DELETE /api/base-layouts/{id}` | none | deletes layout |
| `GET /api/base-layouts/roster` | none | `{operators,drone_capacity}` |
| `GET /api/base-layouts/advanced-inputs` | none | two persisted account facts |
| `PATCH /api/base-layouts/advanced-inputs` | account facts | persists account facts |

The endpoint inventory’s POST body `{slots,slot_id}` conflicts with the observed client’s create body `{name,slots,dual_batch}`. The latter is source-authoritative for the current view; support both only after live verification. `LIVE-API-CAPTURES.md`; `js/views__base-builder.js` Roster operators have `id`, `name`, `rarity`, `char_id`, `evolve_phase`, `level`, and `base_skills`.

Each base skill exposes `buff_id`, `name`, `icon`, description, `room_type`, `phase`, and level. `LIVE-API-CAPTURES.md`

### 8.3 Compute endpoints

| method/path | request | response |
| --- | --- | --- |
| `POST /api/base-layouts/optimize` | `{slots,optimize_facility_types,dual_batch?,batch_swap_hours?,exclude_char_ids?}` | single `{assignment,score,per_slot}` or dual fields |
| `POST /api/base-layouts/report` | `{slots,yield_hours_elapsed?,login_interval_hours?}` | rate arrays plus login summary |
| `POST /api/base-layouts/simulate` | `{slots,dual_batch,batch_swap_hours,duration_hours,start_batch}` | timelines, totals, events |
| `POST /api/base-layouts/explain-slot` | `{slots,slot_id}` | room metric and contributors |
| `POST /api/base-layouts/synergies` | `{slots}` | `{synergies:{...}}` |

`optimize` single output assigns only optimized room slots, as the production fixture demonstrates. Unoptimized inputs remain client-side unchanged when applied. `fixtures/optimize-252-body.json`; `js/views__base-builder.js` `synergies` was `{}` for every captured layout, including optimized layouts.

The UI queries it while opening an assignment popover and merges any hints into cards. `LIVE-API-CAPTURES.md`; `js/views__base-builder.js`

### 8.4 `explain-slot` contract

Response shape is:

```json
{"slot_id":"production_1","room_type":"MANUFACTURE","primary_metric":"productivity",
 "contributors":[{"char_id":"...","buff_id":"...","source_slot_id":"production_1",
 "metric":"productivity_gold","value":40,"counted":true}],"total":105}
```

`counted:false` means evaluated but did not apply. The current UI renders only counted contributors, despite the response’s richer audit intent. `LIVE-API-CAPTURES.md` For Control Center, response is `primary_metric:null`, empty contributors, total `0`. Do not interpret this as its optimization value. `LIVE-API-CAPTURES.md`

## 9. Interpretability features

The optimizer response deliberately has no rationale, alternatives, or confidence. It returns only assignments, score(s), and per-slot score(s). `LIVE-API-CAPTURES.md` Interpretation is instead room-local and report-oriented. “How this is calculated” calls `explain-slot` for a room.

It can name contributing operator, skill/buff, source room, metric, and signed value. `js/views__base-builder.js`; `LIVE-API-CAPTURES.md` It correctly exposes cross-room origin through `source_slot_id`. It can in principle expose rejected clauses via `counted:false`.

It cannot explain the optimizer’s entire weighted objective from the supplied response. `LIVE-API-CAPTURES.md` The view includes an explicit honesty footnote: its contribution display excludes the room’s own base rate from level because that constant is not exposed in this project’s sourced game data. `js/views__base-builder.js` Thus an explanation total is a buff total, not necessarily a full production rate or optimizer score.

Keep that distinction in an equivalent product. `js/views__base-builder.js`

## 10. Divergences and gaps

### 10.1 Earlier base-maker versus shipped Toolbox

The earlier `planner.js` is not an assignment solver. Its `planify` presently evaluates named teams and logs results; it does not construct the PDF’s greedy room-by-room assignment or pairwise-swap refinement. `prior-art/basemaker-scripts/core/planner.js` It uses a hard-coded `SKILLS` table whose keys are bespoke effect names such as `productivity_per_total_cap_bubble` and `is_bubble_absent`.

The PDF describes a generic clause taxonomy instead. `prior-art/basemaker-config/skills.js`; `PDF §§2–3` Its Factory calculation contains acknowledged shortcuts:

Narantuya uses `dorm sum * 20` with a TODO for actual sum; Purestream uses Trading Post count `2` with a TODO; Totter assumes morale never drops below 12; Waai Fu copy is TODO. `prior-art/basemaker-scripts/core/planner.js` Its `Operator.getActiveSkills()` chooses the highest eligible promotion-level skill from game data.

The current client independently groups by buff base ID and selects highest allowed phase/level for display.

Neither proves the server’s exact current skill-selection implementation. `prior-art/basemaker-scripts/entities/operator.js`; `js/views__base-builder.js` The old `Base` model knows an array of nine production rooms and fixed facilities, but does not model the current stable `production_1..9` / `dorm_a..d` payload schema. `prior-art/basemaker-scripts/entities/base.js`; `js/riic-layout.js`

### 10.2 Decisions a reimplementer must make

* Define source-data parsing and the current clause dataset; it is explicitly out of PDF scope.

* Publish metric weights, polarity, configuration discount, iteration thresholds, and iteration caps,
  or keep them versioned internal parameters. The sources do not give values. `PDF §§4,6`

* Choose deterministic room ordering and tie breaks for reproducible suggestions.

* Decide whether power validity is a hard constraint; the client shows it but captures do not settle server enforcement.

* Decide handling for bad IDs, duplicates, over-capacity assignments, unbuilt rooms, and absent targets.

* Decide whether formation disjointness is a hard server rule or trust client `exclude_char_ids`.

* Decide how Training trainee assignment participates in exclusivity and scoring.

* Decide exact morale drain/recovery formulas, swap semantics after depletion, and training completion behavior.

* Decide real Trading order timing; captured simulation explicitly lacks it.

* Decide whether to expose an audit ledger and rejected clauses; the response can, but UI currently hides rejection.

These are gaps, not license to silently guess. The author’s appropriate fallback is zero contribution for an unresolved mechanic. `PDF §9`

## Implementation checklist

1. Represent the layout using the exact slot IDs and conditional fields in §2.

2. Normalize active base skills into the seven-field clause row in §3.

3. Resolve ordinary clauses into a room/entity/metric ledger.

4. Settle pools, peer scaling, then suppression in that order.

5. Apply declared metric weights and target-configuration semantics.

6. Search with greedy whole-layout rescoring followed by local swaps.

7. For dual mode, share availability, balance drafts, then rebalance cross-form swaps.

8. Keep steady-state report and finite morale simulation as separate APIs and models.

9. Return raw attribution sufficient to explain cross-room contributions.

10. Mark every unsupported mechanic as unresolved rather than fabricating a rate.
