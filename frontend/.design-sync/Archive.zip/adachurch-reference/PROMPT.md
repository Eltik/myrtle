# Paste-ready brief

A self-contained description of the feature, distilled from the other documents in this
folder. Paste it into v0 (or any generator) as the prompt, and attach the screenshots you
want it to match. Everything here is fact from the reference implementation — nothing is
invented. Where a decision is yours to make, it says so.

---

## What to build

An **Arknights RIIC base optimizer**: a planning tool where a player recreates the rooms
they have built, staffs them from their operator roster, and gets a projected output — with
an optimizer that proposes a high-scoring staffing arrangement they can accept room by room.

The layout is never generated. The player owns the building; the tool only decides **who
stands where**.

## The domain in one pass

- The base is a fixed six-floor map. Some rooms are **fixed** (Control Center, Reception,
  4 Dormitories, Workshop, Office, Training Room, 6 Activity Rooms); nine slots are
  **flexible** and can each be a Trading Post, Factory, or Power Plant (max 3 Power Plants).
- Every room has a **level** (0 = not built, up to 3; dorms and Control Center to 5) and a
  **capacity** that follows from its type: Factory/Trading Post 3, Dormitory 5, Control
  Center 5, Reception 2, Office/Workshop/Training 1.
- Rooms carry a type-specific setting: Factory → target (Battle Records, Pure Gold,
  Originium Shard ≥ Lv3, Dualchip ≥ Lv3); Trading Post → strategy (Business = LMD-leaning,
  Mining = Orundum-leaning, both ≥ Lv3); Dormitory → ambience; Workshop → material tier;
  Training Room → target level, and it holds a **trainer + trainee** rather than a list.
- Operators have **morale**, drain it while working, and recover it in dormitories. A room
  whose operator hits zero stops producing.
- **Two formations** (A and B) can be staffed for the same base. The player swaps between
  them at a chosen cadence; the tool can plan both at once so that one team rests while the
  other works.
- Power plants must cover the base's power draw; drones and ambience are account-level
  resources shown as counters.

## The one non-obvious mechanic

**Buffs cross rooms.** An operator seated in the Control Center can raise the efficiency of
every Trading Post. So a room's number is *not* a function of its own occupants — it is the
sum of every contribution that reaches it from anywhere in the base. Any per-room display
must be able to name a contributor sitting somewhere else.

Real example from the live tool: explaining a Trading Post returned
`{char_name: "Ascalon", skill_name: "Intel Mastermind", source_slot_id: "control_center", value: 7}`.

## Screens

**1 — Base board (the home screen).**
The grid of room tiles is the primary object and stays on screen. A header carries: a
Build ⇄ Assign mode switch, Report, Optimize, a Form A/B switch with a status line, the base
name, New / quick-save / Save-Load, and power + ambience counters. A results panel is docked
below the grid.

**2 — Room inspector.** Clicking a tile opens it. In Build mode: facility type, level
stepper, the type-specific setting, Clear Slot. In Assign mode: `ASSIGNED (n / capacity) ·
FORMATION A`, the seated operators, and an Assign action.

**3 — Operator picker.** Search plus one row per operator: portrait, name, a **room match**
badge, and every relevant base skill written out in full prose with its numbers emphasised.
Rarity and level are *not* shown in the reference — showing them is an improvement you may
choose to make.

**4 — Optimize.** A modal: which room types to include (chips, only for types actually
built), balance-both-formations vs. this-formation-only, the check-in cadence, and two
persisted account facts the optimizer cannot infer. Run.

**5 — Proposal review.** The optimizer's answer, grouped by facility type, one row per room:
room name, its configured target, the proposed operators in slot order, and a **per-room
accept checkbox**. Nothing is applied until Apply Selected. A warning banner above the list
names any operator who will run out of morale at the chosen cadence, and says which control
would change that.

**6 — Report.** Per-room projected performance: productivity %, per-hour rate, time-to-full,
plus a disclosure on every line that expands into the individual buffs by operator and skill
name, summed to a total. A compare mode puts two layouts side by side with a difference
column between them.

**7 — Simulation.** A time window (1/3/7 days) and a check-in cadence produce: KPI totals,
one card per facility with a cumulative sparkline, a morale sparkline per operator (~60 of
them, grouped by facility), and an events timeline of formation swaps and morale depletions.

## Data shapes

The unit of everything is a **slot**:

```json
{"facility_type":"factory","level":3,"char_ids":["char_225_haak"],"char_ids_b":[],"target":"gold"}
```

`char_ids_b` is Formation B. Slot ids are stable strings: `control_center`, `reception_room`,
`office`, `workshop`, `training_room`, `dorm_a`…`dorm_d`, `production_1`…`production_9`,
`activity_a`…`activity_f`.

Optimize takes `{slots, optimize_facility_types[], dual_batch?, batch_swap_hours?,
exclude_char_ids?}` and returns only `{assignment, score, per_slot}` — no rationale, no
alternatives, no confidence.

Report returns `factory[]`, `trading_post[]`, `dormitory[]`, `yield_login_summary`. Real
values to size the layout against: factory `productivity_pct: 105, total_rate_per_hour:
1.708, hours_to_full: 31.61`; trading post `capacity: 13 (base 10 + 3), efficiency_pct: 138,
total_rate_per_hour: 1047.826 LMD`; dormitory `base 2 + ambience 2 + operator 3 = 7
morale/hour`; summary `recommended_login_hours: 22.39` with a named bottleneck room.

Explain returns `contributors[]` of `{char_name, skill_name, source_slot_id, metric, value,
counted}` and a total.

## Density — design for the real numbers

A staffed base seats about **60 operators** across ~25 room tiles, from a roster of ~350.
The proposal review is ~20 rows of 5 portrait slots. The morale view is ~60 sparkline cards
at once. The optimize modal holds 9 scope chips + 2 + 4 chips plus two setting rows. Nothing
here is a five-element demo screen; if a layout only looks right with three rooms, it's wrong.

## What the reference gets right — keep it

- The board is the interface. Rooms are edited in place, never on a separate page.
- Build and Assign are separate modes, so one popover never has to hold both jobs.
- The optimizer **proposes**; the player accepts per room. It never silently overwrites.
- Every number can explain itself, down to the individual operator and skill.
- The cadence assumption and the two account facts are stated in the open, because they
  change the answer.
- Empty states are written per card ("Not enough data"), not one page-level blank slate.

## What it gets wrong — fix it

- **The room popover is overloaded.** Level, target, strategy, ambience, staff, skill
  explanations and removal all pile into a small floating panel. Use a stable inspector
  panel instead, so rooms can be compared without losing state.
- **Fragmented vocabulary.** Optimize / Suggest Setup / Run / Report / Daily Yield /
  Simulate Output are six names for three ideas. Name the stages once: Configure →
  Assign → Review.
- **Results live in four places** — a docked panel, a modal, a drawer, and a simulation
  section. Consolidate into one results surface.
- **The optimizer hides its score.** It computes a total and per-room breakdown and shows
  neither. Show what changed and why.
- **Formations are hidden behind a toggle.** Which team is working and which is resting
  should be visible without opening anything.
- **No select-all / production-only shortcut** on the optimize scope chips.
- Charts carry no axes, labels, or tooltips at all — sparkline plus a number. That is a
  legitimate choice at this density, but at least label the axis units somewhere.

## Styling

Not specified here. Use the design system in this project. `DESIGN.md` in this folder
documents the reference tool's own visual language (dark, wide-tracked uppercase labels,
facility-coloured accents, a 23-track CSS grid at 64px with 32px elevator columns) — read it
if you want the genre, ignore it if your product has its own.
