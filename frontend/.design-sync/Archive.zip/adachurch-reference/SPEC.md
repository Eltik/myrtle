# Closure's Toolbox — Base Builder design reference

The **UI and information-architecture** layer of the reference: every screen, overlay, room position, and control of `tools.adachurch.com/#/base`. It covers what the interface *is*, not what it looks like or how it computes — see `DESIGN.md` for the visual system, `HOW-IT-WORKS.md` for the mechanics, `API.md` for the data contract, and `screens/` for 24 captures of the live tool (2026-08-15).

## 1. Purpose and mental model

Closure's Toolbox is a planner and assignment optimizer for the Arknights RIIC base. The player first recreates the rooms they have actually built, their levels, and what production rooms are making. They then use their imported operator roster to staff those rooms manually or ask the tool to propose a high-scoring setup.

The mental model is a small building-management board: configure the building, put people into rooms, inspect projected output, and save alternatives. “Optimize” is not a layout generator. It preserves the built rooms and their configuration and rearranges operators within the selected room types. In dual-formation mode it plans two alternating work teams to accommodate Morale depletion.

## 2. Information architecture

The page title is **Closure's Toolbox / Base Builder**. The subtitle is “Plan your Rhodes Island Infrastructure Complex layout.” There is one primary page, with transient slot popovers and several modal overlays.

### Main page regions

```text
┌─────────────────────────────────────────────────────────────────────────────┐
│ Closure's Toolbox                                                            │
│ Base Builder                                                                  │
│ Plan your Rhodes Island Infrastructure Complex layout.                       │
├─────────────────────────────────────────────────────────────────────────────┤
│ [Building Mode ⇄ Operators Mode] [Report] [Optimize]     [Form A | Form B]  │
│ Base name [Single Form switch] [New] [quick save] [Save / Load]             │
│ Unsaved changes / Viewing & editing Formation A     power | drones | ambience│
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│                    LARGE BASE GRID / BUILDING MAP                           │
│          left wing   elevator spine   centre   elevator   right wing         │
│                                                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│ Daily Yield panel: current daily yield; login-loss drawer; simulation drawer│
└─────────────────────────────────────────────────────────────────────────────┘
```

The grid is the dominant interactive object. Clicking a room opens an anchored popover beside that tile, rather than navigating away. The mode control changes the contents of that popover from room-building controls to staffing controls. The **Optimize** button is enabled only in Operators Mode.

### Screen and overlay inventory

| Surface | Entry | Contents | Exit |
|---|---|---|---|
| Main Base Builder | route `#/base` | header, mode/actions, formation controls, grid, yield panel | persistent page |
| Build room popover | click a room in Building Mode | room type, level, type-specific setup, Clear Slot | click outside or another tile |
| Assignment room popover | click a built room in Operators Mode | assigned people, skills, assignment actions | click outside or another tile |
| Operator picker modal | **Assign**, **Assign Trainer**, or **Assign Trainee** | search field and roster rows | close corner / backdrop |
| Suggest Setup modal | **Optimize** | scope, formation choice, cadence, account facts, Run; then proposed changes | close, Discard, or Apply Selected |
| Account Facts modal | gear/account-facts chip in Suggest Setup | two opt-in assumptions | close corner / backdrop |
| R.I.I.C Report modal | **Report** | per-room current performance and optional comparison | close corner / backdrop |
| report comparison selector | click either comparison field | Current Layout, current Form A/B, saved layouts | choose or click elsewhere |
| Save / Load modal | **Save / Load** | five save slots and save/load/overwrite/delete actions | close corner / backdrop |
| confirmation modal | delete or overwrite | question, Cancel, destructive confirmation | Cancel, Confirm, backdrop |
| Daily Yield deep dive | **Deep Dive** in lower panel | simulation setup or results | same disclosure control |
| missed-check-in drawer | “Missed a check-in? See what it cost” | login interval and period controls, yield loss | same disclosure control |

### Navigation and mode transitions

**Building Mode** is the initial mode. The mode card is a two-state toggle labelled **Building Mode** and **Operators Mode**. Switching does not discard layout or assignment state. The grid remains visible, but each clicked tile now opens the appropriate version of the room popover.

The dual-formation control defaults to enabled. When enabled, **Form A** / **Form B** selects which assignment array is shown and edited. When disabled, the control is visually a **Single Form** toggle and assignments are one static team.

## 3. Base grid — layout model

The grid is an exact six-floor, 23-track map. Tracks are columns, not room columns: normal tracks are 64 px wide in source geometry and elevator tracks are 32 px wide. The column template is therefore 23 entries: 64 × 7, 32, 64 × 4, 32, 64 × 3, 32, 64 × 6. Elevator columns are 8, 13, and 17 (one-based).

The left elevator exists on floors 1–6. The centre elevator exists on floors 1–6. The right elevator exists only on floors 2–5. Each elevator is a separate 1×1 decorative tile at every available floor.

Rows 1–6 are the floors, top to bottom. Left-wing rooms grow leftwards from the left elevator. Rooms on its right grow rightwards from it. The right wing follows the same pattern around the right elevator.

The centre/left composition is intentionally asymmetric; reproduce positions below rather than trying to make a symmetric office plan.

### Exact room placement

| Floor | Left of left elevator | Right of left elevator | Left of right elevator | Right of right elevator |
|---|---|---|---|---|
| 1 | — | Control Center, 4×2, beginning at track 9 | — | — |
| 2 | — | Reception Room, 3×1, beginning at track 14 | — | — |
| 3 | Production 1, 6, 9 (each 2×1) | Dormitory A (3×1), then 1×1 path | Workshop (2×1), then 1×1 path | Activity Room A, Activity Room D (each 3×1) |
| 4 | 1×1 path; Production 2, 5, 8 (each 2×1) | 1×1 path; Dormitory B (3×1) | Office (2×1), then 1×1 path | Activity Room B, Activity Room E (each 3×1) |
| 5 | Production 3, 4, 7 (each 2×1) | Dormitory C (3×1), then 1×1 path | Training Room (2×1), then 1×1 path | Activity Room C, Activity Room F (each 3×1) |
| 6 | — | 1×1 path; Dormitory D (3×1) | — | — |

Control Center spans floors 1–2 and tracks 9–12. Reception Room is at floor 2, tracks 14–16. There are nine same-sized flexible production slots, called `production_1` through `production_9` internally. The map also has eleven non-interactive path tiles.

There are six fixed Activity Room tiles. Activity Rooms have no operator slots and no production setup, but are still displayed as base rooms.

### Fixed versus flexible locations

Fixed locations begin with their named facility type. Fixed types cannot be changed, and their level stepper can reach level 0 (“Not Built”) except the Control Center. The nine production locations begin empty and are labelled **Empty**. Each flexible slot can become exactly one of **Trading Post**, **Factory**, or **Power Plant**.

Flexible choices are constrained globally by the facility maximum counts. The current choice becomes disabled and labelled “(max N)” when its limit is reached.

| Fixed slot family | Count | Facility type | footprint | allowed levels | worker capacity by level |
|---|---:|---|---:|---|---|
| Control Center | 1 | Control Center | 4×2 | 1–5 | 1, 2, 3, 4, 5 |
| Reception | 1 | Reception Room | 3×1 | 0–3 | 2, 2, 2 |
| Dormitories | 4 | Dormitory | 3×1 | 0–5 | 5, 5, 5, 5, 5 |
| Workshop | 1 | Workshop | 2×1 | 0–3 | 1, 1, 1 |
| Office | 1 | Office | 2×1 | 0–3 | 1, 1, 1 |
| Training | 1 | Training Room | 2×1 | 0–3 | 2 roles: trainee + trainer |
| Activity | 6 | Activity Room | 3×1 | 0–3 | 0 |

| Flexible type | Maximum count | footprint | allowed levels | worker capacity by level | power at levels 1 / 2 / 3 |
|---|---:|---:|---|---|---|
| Trading Post | 5 | 2×1 | 1–3 | 1, 2, 3 | -10 / -30 / -60 |
| Factory | 5 | 2×1 | 1–3 | 1, 2, 3 | -10 / -30 / -60 |
| Power Plant | 3 | 2×1 | 1–3 | 1, 1, 1 | +60 / +130 / +270 |

The power tally is shown as “available minus consumed / available.” It is calculated from the listed facility power values. Negative net power receives a shortage treatment (`riic-power-short`). The other main-grid tallies are drone capacity when the roster endpoint supplies it, and total Dormitory Ambience.

### Tile contents

A normal tile shows facility name and a row of level pips. An unbuilt fixed tile says **Not Built**. An empty flexible tile says **Empty** and has a “Choose a facility” tooltip. Control Center instead carries a special “Control Center / Level of Control_Interface / VER N.0” badge.

In Operators Mode, assigned operators appear as compact portrait/initial chips directly on a tile.

## 4. Control inventory

Defaults below are source defaults for a new base, not assumptions about a loaded account.

### Header, mode, and saving controls

| Label | Type | Options / default | Behavior |
|---|---|---|---|
| Building Mode / Operators Mode | two-state mode card | default Building Mode | changes room-popover purpose; Optimize only enables in Operators Mode |
| Report | button | — | opens R.I.I.C Report |
| Optimize | button | disabled in Building Mode | opens Suggest Setup in Operators Mode |
| Form A / Form B | binary switch card | Form A default | selects displayed/editable formation when dual mode is enabled |
| Base name | text input | “Untitled Base” | names future or current save |
| Single Form | toggle | off by default, meaning dual mode is on | chooses one static roster rather than rotating A/B |
| New | button | — | clears to the new-base layout and dual mode |
| quick-save icon | icon button | disabled until a saved layout is loaded | updates the current save slot |
| Save / Load | button | — | opens five-slot save modal |

The formation switch hint reads “Viewing & editing Formation A” or “Viewing & editing Formation B.” The status line is blank, **Unsaved changes**, **Saved**, or **All slots full**.

### Build room popover controls

The popover is selected by a grid tile and reflects that tile only.

| Label | Type | Full option set | Default / availability | Behavior |
|---|---|---|---|---|
| facility type | icon chip group `riic-slot-type-btn` | Trading Post; Factory; Power Plant | only on empty/flexible production slots; none selected initially | selects room type, subject to maxima |
| level | minus/value/plus stepper | whole-number levels in facility range | flexible starts at 1 after type selection; fixed starts at 1, Control Center cannot be 0 | changes level; trims excess assigned workers if capacity falls |
| Trading Strategy | two icon choices `riic-strategy-btn` | Business Strategy — “LMD-leaning orders”; Mining Strategy — “Orundum-leaning orders” | only a level-3 Trading Post; initially unset | sets trading order strategy |
| Production Target | chip group | Battle Records; Pure Gold; Originium Shard; Dualchip | Factory; initially unset | selects target; Shard and Dualchip appear only at level 3 |
| Ambience | numeric stepper/input | 0–5000, step 100 | Dormitory, 0 | contributes to Dormitory recovery calculation |
| Target Specialization Level | chip group | Level 1; Level 2; Level 3 | built Training Room; initially unset | configures training target |
| Target Material Tier | chip group | Tier 2 Materials; Tier 3 Materials; Tier 4 Materials; Tier 5 Materials | built Workshop; initially unset | configures workshop target |
| Clear Slot | button | — | flexible slot only | resets it to Empty, level 1, and blank A/B assignments |

“Not Built” appears at level 0 for eligible fixed rooms, with the explanation “Not built yet — no capacity, no bonuses.” Trading strategy is deliberately unavailable below level 3. Factory targets are level-gated rather than disabled: only valid chips are rendered.

### Assignment room popover controls

| Label | Type | Options / default | Behavior |
|---|---|---|---|
| Assigned (N / capacity) | readout | includes “Formation A/B” in dual mode | header for current room assignments |
| List view / Tile view | two icon toggle | List view default and persisted locally | switches rich rows versus portrait tiles |
| Assign | button | appears while a standard room has capacity | opens operator picker |
| Assign Trainer | button | Training Room trainer role only | opens picker filtered/sorted for Training skill |
| Assign Trainee | button | Training Room trainee role only | opens picker; trainee needs no matching skill |
| remove operator | per-person icon button | — | unassigns that operator from the current formation |
| Clear All | button | standard rooms; clears both roles for Training | removes all room assignees |

Training Room is not a two-person generic capacity list. It always presents the separate **Trainee** and **Trainer** roles. In dual mode, Dormitories are automatic resting rooms. Their popover says who from the opposite formation is resting while the selected formation works, and does not allow direct assignment.

### Suggest Setup controls

| Label | Type | Full option set | Default | Behavior |
|---|---|---|---|---|
| Optimize Which Rooms | multi-select facility chip group | any built: Control Center, Trading Post, Factory, Power Plant, Dormitory, Reception Room, Workshop, Office, Training Room | all built non-Activity types selected | limits assignments the optimizer may change |
| Balance Both Formations | formation-choice chip | Balance Both Formations | default in dual mode | sends both A and B for simultaneous, balanced optimization |
| This Formation Only (A/B) | formation-choice chip | visible only in dual mode | not default | optimizes viewed formation, excluding people in other formation |
| How often do you check in? | cadence chip group | Once a day — One login, one swap; Twice a day — Morning and evening, most common; 3x a day — Frequent check-ins; Intensive — Every 6h, not needed for most bases | Twice a day (12 h) | dual optimizer rotation cadence |
| account-facts chip | button | current Influence/Territory setting · N extra Recruit slots | unknown / 0 initially | opens Account Facts modal |
| Run | button | disabled when no scope is selected | — | calls optimizer |
| Apply Selected | button | result state only | — | applies checked proposal rows |
| Discard | button | result state only | — | closes and drops proposal |

The actual scope options are conditional on rooms built in the particular base. The exhaustive potential set is listed above. Each result room card has a checkbox (`riic-suggest-row-check`) so the user can apply only selected changes.

### Daily Yield and simulation controls

| Label | Type | Full option set | Default | Behavior |
|---|---|---|---|---|
| Deep Dive / Hide Deep Dive | disclosure button | two states | collapsed | reveals Simulate Output |
| Missed a check-in? See what it cost | disclosure button | two states | collapsed | reveals interval impact calculator |
| Login interval | chip group | 6H; 12H; 24H; Custom | 24H | used for yield loss projection and Report warning |
| Custom | chip | Custom | inactive | reveals numeric interval input |
| custom value | number input | minimum 1; capped at 8784 hours | current interval | accepts a user interval |
| Hours / Days | two-chip unit group | Hours; Days | Hours | unit for custom value |
| Period | chip group | Daily; Weekly; Monthly; Yearly | Daily | period for missed-check-in output |
| simulation duration | chip group | 1d; 3d; 7d | 1d (24 h) | total simulation window |
| How often do you check in? | cadence chip group | Once a day; Twice a day; 3x a day; Intensive | Twice a day | dual simulation swap frequency |
| Run | button | — | — | POSTs current grid to simulation |
| Adjust Settings | button | result state only | — | returns to simulation settings |

In Single Form mode the simulation replaces cadence controls with an explanation that no backup formation will swap in.

### Account Facts controls

The modal is titled **Account Facts**. It explains that these are two things the optimizer cannot read from the synced roster and saves them for future Suggest runs.

| Label | Type | Full option set | Default | Behavior |
|---|---|---|---|---|
| Wang's Expedience (is your Influence ≥ Territory?) | three-chip group | Influence ≥ Territory; Territory > Influence; Not set | Not set | records Wang skill condition |
| Lin's Meritocracy (open Recruit slots beyond the first) | four-chip group | 0; 1; 2; 3 | 0 | records extra Recruit slots |

## 5. Operator roster surface

The main page does not show a standalone roster browser. The roster appears in the Operator Picker modal after the user chooses a room and an assignment slot. Roster data is fetched from `/api/base-layouts/roster` and is assumed to be account-synced. The picker starts with a single text field, placeholder **Search operators...**.

Search is case-insensitive substring matching on operator name. It does not expose visible filters for rarity, level, class, or skill. For a room with a relevant skill type, matching operators are sorted before non-matches. A matching row receives a **Room match** badge.

The row itself is the assignment action; there is no separate “add” button. Selecting a person globally removes them from every A/B room and Training role before assigning them to the selected target. That makes every operator unique across the entire setup, including both formations.

### One operator row

Each row has a portrait and the operator name. It shows every active, room-relevant base skill as a labeled skill tag plus rich-text description. The tag includes a room category icon: Control, Factory, Training, Power, Office, Dormitory, Trading Post, Workshop, or Reception. Only skills unlocked by the saved evolve phase and level are shown.

Duplicate versions of the same skill are deduplicated in favour of the highest currently valid one. If the person is assigned elsewhere, a secondary line says “Currently in [room] · [role] · Formation [A/B]” as applicable. The picker deliberately leaves already-selected people out of its immediate room/other-Training-role list.

The supplied roster payload does not include a full roster object schema or visible rarity/level rendering template. The current live module visibly renders name, portrait, matching status, current assignment, and base skills; rarity and level are not rendered here. Do not invent rarity stars or a level badge in a faithful recreation.

### Batch assignment behavior

In dual mode the grid tile and popover only show the active formation’s workers. Dorm residents are derived automatically from the inactive formation’s people, distributed up to each dorm’s capacity. The user assigns working rooms, not dorms. Suggestion result cards visibly state people being **Pulling [name] (from room · Formation X)** and **Removing [names]**.

## 6. Optimize action

The user changes to Operators Mode, presses **Optimize**, chooses scope and—when applicable—formation/cadence, then presses **Run**. At least one optimize-scope facility type must be selected; the Run button disables at zero. The tool allows partially staffed and partially configured rooms through to optimization, but the returned score necessarily reflects the configuration supplied.

The optimizer receives a `slots` object keyed by slot ID. Each slot carries `facility_type`, `level`, and the relevant assignment(s). Trading Posts additionally carry `strategy`; Factories `target`; Dormitories `ambience`; Training Rooms `target_level`; Workshops `target_tier`. It also sends `optimize_facility_types` as selected facility IDs.

Balanced dual mode adds `dual_batch: true` and `batch_swap_hours`. Single-formation optimization in dual mode sends the opposite team as `exclude_char_ids`.

```jsonc
// POST /api/base-layouts/optimize — representative shape
{
  "slots": {
    "production_1": {
      "facility_type": "trading_post",
      "level": 3,
      "strategy": "gold",
      "char_ids": ["char_..."],
      "char_ids_b": ["char_..."]
    },
    "production_3": {
      "facility_type": "factory",
      "level": 3,
      "target": "gold",
      "char_ids": [],
      "char_ids_b": []
    }
  },
  "optimize_facility_types": ["trading_post", "factory"],
  "dual_batch": true,
  "batch_swap_hours": 12
}
```

During the request the modal replaces its body with **Suggest Setup** and “Scoring your roster against every built room...”. No duration, progress percentage, or cancellation affordance is present. The source does not specify a measured response time; treat it as asynchronous and use an indeterminate loader. The single-formation saved response score is **476.0875**.

Its nonzero room scores range from **5.0** and **5.5** to **73.5**, across nine production slots. The dual saved response scores are **428.9875** for A and **429.975** for B.

## 7. Results readout

### Optimizer proposal

The response is assignments keyed by slot ID plus one aggregate score. Dual response uses `assignment_a`, `assignment_b`, `score_a`, `score_b`, and a `justification` object. The rendered UI prioritizes change review, not the raw score: it groups proposed cards by Formation then facility type.

A card shows the room/facility icon, configured target/strategy where present, up to five portrait positions, checkbox, outgoing names, and incoming names with their origin. The proposal does not display score values in the template. For dual proposals it includes a verdict panel.

The saved result says **“Holds up over 7 days swapping twice a day”** and “Nobody runs out of Morale at this cadence.” The source also supports a warning count and names when operators deplete. Applying checked cards writes those operators into the relevant A/B grid assignments and immediately redraws the portrait chips on the grid.

### R.I.I.C Report

**Report** opens a modal headed **R.I.I.C Report** with “Projected performance at the current layout & assignment.” It divides rows into **Factory**, **Trading Post**, and **Dormitory** sections. Factory row states target, level, productivity percentage, `Full in` cap time, item image/name, and rate **/hr**.

It has explicit states for **Not configured**, target locked at this level, and “exact rate not exposed by game data.” Trading Post row states strategy, level, `Full in`, item rate **/hr**, **Order capacity**, and **Order efficiency** percentage. Dormitory row states level, Ambience, then **Base regen**, **Ambience bonus**, **Operator bonus**, and **Total**, each in **/hr**.

Every normal row can expand **How this is calculated**. That fetches `/api/base-layouts/explain-slot` and shows contributor/operator breakdown when available. `Full in` turns into a warning when it is sooner than the chosen login interval. The Report has **Compare**.

Comparison opens two independent layout selectors and a central **Difference** panel. Selector choices are Current Layout, current Form A, current Form B, and every saved layout. Difference is aggregate hourly item-rate deltas, Trading Capacity, Trading Efficiency percentage, and Dormitory Morale **/hr**.

### Daily Yield lower panel

The always-present lower panel title is **Daily Yield**. Without active Factory/Trading staffing it says “Assign operators to a Factory or Trading Post to see projected daily yield.” With report data it shows a “Login before [day, time]” prompt and item rows. Each item row shows icon, item name, rounded amount **/day**, and optionally “−N lost” when a selected cadence/period loses output.

The missed-check-in calculation can show Daily, Weekly, Monthly, or Yearly amounts.

### Simulation results

Simulation results begin **Results · 3d** for the saved 72-hour example. At the top are total tiles grouped by Factory target, trading item, and **Morale Recovered**. For the supplied 72-hour response, Factory totals are Pure Gold: **118.5**, **112.5**, **105.0**; Battle Records: **67.61**, **50.93**. Dormitory recovery totals are **122.4**, **122.4**, **115.2**, and **115.2**, or **+475.2 Morale Recovered** combined.

The two Trading Posts show **90.0% efficiency**, **72h** productive, **0h** idle. The tool explicitly notes this is a steady-state estimate, not order-by-order real arrival timing. The **Output by Facility** section is a grid of cards.

Each card has room name, target/strategy and efficiency, a headline output amount, “produced” or “Morale recovered,” productive/idle information, and a cumulative line/area chart over the selected duration. Factory samples above range roughly **50.9–118.5 units** in three days. The **Morale over time** section is a multi-operator chart/list built from timestamped morale values and room location.

The saved timeline contains values from **2.4** through **24.0** morale, sampled at 12-hour cadence. The **Events** section logs events with elapsed time and description. The supplied response logs five swaps at 12h, 24h, 36h, 48h, and 60h, alternating “Swapped to Batch B” and “Swapped to Batch A.” If nobody depletes it says “No events. Nobody ran out of Morale during this window.”

## 8. Secondary surfaces and persistence

### Save / Load

The save modal says “5 slots per account.” It always renders five numbered rows. An empty row is labelled **Empty Slot** and offers one icon action, “Save current layout here.” A filled row displays layout name, saved date, a **Currently Loaded** pill if applicable, plus icon actions Load, Overwrite, and Delete.

Overwrite asks “Overwrite [name] with the current layout? This cannot be undone.” Delete asks “Delete this saved base? This cannot be undone.” New, quick-save, and save/load use the base-layouts API; a local copy of current work is also retained in local storage as `riic:lastBase`. There is no import/export surface in either supplied view module.

| Save / Load control | Type | Behavior |
|---|---|---|
| Load | icon button on filled row | loads that saved base into the grid |
| Save current layout here | icon button on empty row | creates a new saved layout in that slot |
| Overwrite | icon button on filled row | asks for confirmation, then replaces that saved slot |
| Delete | icon button on filled row | asks for confirmation, then removes that slot |
| Cancel | button in confirmation | closes without changing data |
| Confirm / Overwrite / Delete | button in confirmation | executes the named destructive action |

### Report controls

| Report control | Type | Options / behavior |
|---|---|---|
| Compare | toggle button | switches between one report and three-column comparison |
| left comparison field | dropdown trigger | Current Layout; This Layout · Formation A; This Layout · Formation B; saved layout names |
| right comparison field | dropdown trigger | same option set as left |
| How this is calculated | per-room disclosure | loads and opens that room's calculation breakdown |
| close | corner icon button/backdrop | closes Report modal |

### Control Center opt-in

There is no special Control Center configuration UI beyond its fixed grid tile and level. The relevant optimizer opt-in is Account Facts, described above. Wang’s condition is a three-way explicit choice rather than an assumption. Lin’s condition is a four-value integer choice rather than a free text field.

### Current-live changes relative to saved module

The live copy adds report calculation expansion (`riic-explain-toggle`). It adds the Daily Yield panel, “Login before” hint, missed-check-in cadence/period projection, and custom hours/days input. It adds Report comparison and its difference card. It adds simulation duration choices and detailed simulation result cards/charts/events.

It adds richer dual-formation dormitory auto-resting copy and tile/list assignment presentation refinements. These live additions should be included in any redesign; they are not speculative.

## 9. States

| State | What the user sees / can do |
|---|---|
| initial load | grid has a “Loading base...” overlay while layouts and roster fetch |
| fresh base | named Untitled Base; dual Form A active; fixed rooms level 1; flexible slots Empty; no save ID |
| empty flexible tile | Empty tile; Build popover says “Pick a facility type” |
| unbuilt fixed room | Not Built, no capacity/bonuses, instruction to use Building Mode |
| power shortage | power tally becomes shortage state |
| no roster match | picker says “No operators match your search.” |
| no active production | Daily Yield and interval panel use their respective no-production messages |
| no simulation assignment | simulation results say “No operators assigned to simulate.” |
| invalid optimize scope | all scope deselected; explanatory text and disabled Run |
| optimization loading | “Scoring your roster against every built room...” indeterminate loader |
| optimizer failure | “Something went wrong running the optimizer.” |
| simulation loading | “Running the simulation...” indeterminate loader |
| simulation failure | “Something went wrong running the simulation.” |
| report failure | “Something went wrong building the report.” |
| interval failure | “Something went wrong checking that.” |
| no proposal changes | “No changes to suggest with this roster and setup.” |
| dual depletion | warning verdict with depleted count/names, if returned |
| save capacity reached | “All slots full” after save-new attempt |
| unsaved edits | status “Unsaved changes”; quick-save enabled only when a saved slot is current |

## 10. Density and volume

The map includes 25 room tiles: 1 Control Center, 1 Reception, 4 Dorms, 1 Workshop, 1 Office, 1 Training, 6 Activity Rooms, and 9 flexible production slots. It additionally includes 11 path tiles and 16 elevator tiles, so the visual board contains 52 tiles/shapes before operator portrait chips. A fully built 2-5-2-style arrangement can place nine production facilities plus the fixed spaces.

In the supplied simulation, nine production slots are assigned across two formations. The saved dual optimizer response assigns 23 workers in each formation: seven rooms with three operators and two rooms with one operator. Those portrait clusters must fit on the map while preserving legibility. Fixed rooms can add up to 5 Control Center workers, 4×5 Dorm capacity, 2 Reception workers, and several one-person service rooms.

The roster is potentially large; the picker is a scrollable list, not a grid of all operators. The densest modal is Suggest Setup: scope chips, two formation-choice chips, four cadence chips, account-facts trigger, then many checkable room cards grouped by formation and type. The densest report state is side-by-side comparison: two per-room reports plus a difference column.

## 11. Design critique

Keep the board-first workflow. The facility grid gives the user an immediately understandable spatial model and makes room-level setup feel grounded in the game. Keep the Build/Operators mode split, because it prevents type/level controls and staff controls from competing inside every popover.

Keep proposal review with per-room checkboxes; it gives the optimizer appropriate advisory status instead of silently overwriting the player’s decisions. Keep explicit rotation cadence and the Account Facts opt-in: both expose assumptions that materially affect the result. The current interface overloads the room popover.

A level stepper, target chips, strategies, ambience, staff, skill explanations, view switch, and removal controls can all pile into a small anchored surface; a redesigned inspector panel would be more stable and easier to compare across rooms. The source uses inconsistent vocabulary: **Optimize**, **Suggest Setup**, **Run**, **Report**, **Daily Yield**, and **Simulate Output** are related but not clearly staged.

The redesign should make the progression explicit: Configure → Assign/Optimize → Review projected output. Dual formations are powerful but cognitively hidden behind a toggle and compact Form A/B switch. The redesign should make active versus resting team status persistent and show the automatic dormitory implication before a user clicks a dorm. The optimizer result suppresses its numerical score despite receiving it.

That is defensible if score is abstract, but the redesign should show an intelligible objective or a clear “why this changed” summary alongside the proposals. The lower yield panel, Report modal, interval calculator, and simulation all communicate output at different time horizons. They are useful, but fragmented; a redesign should consolidate them into one results workspace with tabs or progressively disclosed sections.

The room-type scope is conditional and exhaustive only by what is built, which is good, but there is no visible “select all / production only” shortcut. That would be a helpful redesign addition, clearly distinguished from the original behavior.

## Gaps — closed by screenshots

This section originally listed what could not be recovered from the JS modules alone.
The live tool was then captured on 2026-08-15; see `SCREENSHOTS.md` for the index and `screens/` for the images. Status of each gap:

- **Visual hierarchy and spacing of the grid and overlays** — closed. See `01`, `02`, `06`, `15`.
- **Operator picker contents** — closed. See `09`. Each row is portrait + name + a
  "ROOM MATCH" badge + every relevant base skill written out in full prose with the numbers emphasised. Rarity and level are *not* shown in the picker.
- **Roster volume** — partially closed. The morale readout in `23` enumerates
  "1 of 60 operators", so a staffed 2-5-2 base holds ~60 assigned operators; the total roster size behind the picker's scroll is still unmeasured.
- **Charts** — closed. See `22` (per-facility cumulative sparklines), `23` (per-operator
  morale sparklines with current/max), `24` (events timeline). There are no axes, legends, or tooltips: every chart is an unlabelled sparkline paired with a number.
- **Save / Load and Trading Strategy presentation** — closed. See `05` (five slots, icon-only
  row actions) and `06` (strategy is two large art cards, not chips).
- **Network timing and full report payloads** — still open, and not needed for a redesign.

Two things the capture added that the source did not reveal:

- The optimizer surfaces a **morale warning** above its proposal, naming the affected
  operator and pointing at the control that would change the outcome (`11`).
- Empty states are authored **per card** ("Not enough data" on each facility), not as one
  page-level blank slate (`04`).
