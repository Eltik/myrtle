import { ChevronRight, Heart, Shield, Swords, Zap } from "lucide-react";
import Image from "next/image";
import { Badge } from "~/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "~/components/ui/card";
import { Progress } from "~/components/ui/progress";
import { ScrollArea } from "~/components/ui/scroll-area";
import { Skeleton } from "~/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "~/components/ui/tabs";
import { formatProfession, formatSkillType, formatSubProfession, insertBlackboard, parseSkillStaticLevel, removeStyleTags } from "~/helper";
import { descriptionToHtml } from "~/helper/descriptionParser";
import { getAttributeStats, getMaxAttributeStats } from "~/helper/getAttributeStats";
import type { CharacterData } from "~/types/impl/api";
import type { OperatorRarity } from "~/types/impl/api/static/operator";

function CharacterDialogueCard({ data }: { data: CharacterData }) {
    const { static: operatorData, skills } = data;

    if (!operatorData) return null;

    const { name, appellation, rarity, profession, subProfessionId, description } = operatorData;

    const getRarityStars = (rarity: OperatorRarity) => {
        const starCount = parseInt(rarity.split("_")[1] ?? "0", 10);
        return "★".repeat(starCount);
    };

    const getOperatorStats = () => {
        const moduleData = data.static?.modules.find((module) => module.uniEquipId === data.currentEquip)?.data;
        const battleEquip = moduleData ? { [data.currentEquip]: moduleData } : undefined;
        return getAttributeStats(data, data.level, battleEquip);
    };

    const attributeStats = getOperatorStats();

    return (
        <Card className="grid max-h-[calc(100vh-7rem)] w-full max-w-2xl gap-6 overflow-hidden rounded-lg border-0 shadow-lg md:py-6">
            <CardHeader className="relative">
                <div className="relative h-64 w-full">
                    <Image
                        alt={name}
                        className="h-48 w-full rounded-t-lg"
                        fill
                        loading="lazy"
                        sizes="100vw"
                        src={`https://raw.githubusercontent.com/fexli/ArknightsResource/main/charpack/${data.skin ? data.skin.replaceAll("@", "_").replaceAll("#", "_") : (data.tmpl?.[data.currentTmpl ?? 0]?.skinId ?? "").replaceAll("@", "_").replaceAll("#", "_")}.png`}
                        style={{
                            objectFit: "contain",
                        }}
                    />
                </div>
                <div className="absolute right-0 bottom-0 left-0 rounded-md bg-gradient-to-t from-gray-900 to-transparent p-4">
                    <CardTitle className="font-bold text-3xl">{name}</CardTitle>
                    <p className="text-lg">{appellation}</p>
                    <div className="mt-2 flex items-center space-x-2">
                        <Badge className="bg-card" variant="outline">
                            {getRarityStars(rarity)}
                        </Badge>
                        <Badge className="cursor-pointer">{formatProfession(profession)}</Badge>
                        <Badge className="cursor-pointer">{formatSubProfession(subProfessionId)}</Badge>
                    </div>
                </div>
            </CardHeader>
            <CardContent>
                <Tabs className="w-full" defaultValue="info">
                    <TabsList className="grid w-full grid-cols-5">
                        <TabsTrigger value="info">Info</TabsTrigger>
                        <TabsTrigger value="stats">Stats</TabsTrigger>
                        <TabsTrigger value="skills">Skills</TabsTrigger>
                        <TabsTrigger value="modules">Modules</TabsTrigger>
                        <TabsTrigger value="talents">Talents</TabsTrigger>
                    </TabsList>
                    <TabsContent value="info">
                        <ScrollArea className="h-[200px] w-full rounded-md border p-4">
                            <div className="space-y-2">
                                <div className="flex flex-col gap-4">
                                    <div>
                                        <h3 className="font-semibold">Description</h3>
                                        <p className="text-muted-foreground text-sm">{insertBlackboard(description, [])}</p>
                                    </div>
                                    <div className="flex flex-col">
                                        <h3 className="font-semibold">Recruited</h3>
                                        <span className="text-muted-foreground text-sm">{new Date(data.gainTime * 1000).toLocaleString()}</span>
                                    </div>
                                </div>
                                <div>
                                    <h3 className="font-semibold">Trust</h3>
                                    <div className="flex flex-row items-center justify-start gap-2">
                                        <Progress className="w-[60%]" max={100} value={(data.static?.trust ?? 0) / 2} />
                                        <p className="text-muted-foreground text-sm">{(data.static?.trust ?? 0) / 2}%</p>
                                    </div>
                                </div>
                            </div>
                        </ScrollArea>
                    </TabsContent>
                    <TabsContent value="stats">
                        {attributeStats ? (
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <h4 className="mb-2 font-semibold">Combat Stats</h4>
                                    <AttributeRow icon={<Heart className="h-4 w-4" />} label="HP" max={getMaxAttributeStats(data)?.maxHp} value={Math.round(attributeStats?.maxHp ?? 0)} />
                                    <AttributeRow icon={<Swords className="h-4 w-4" />} label="ATK" max={getMaxAttributeStats(data)?.atk} value={Math.round(attributeStats?.atk ?? 0)} />
                                    <AttributeRow icon={<Shield className="h-4 w-4" />} label="DEF" max={getMaxAttributeStats(data)?.def} value={Math.round(attributeStats?.def ?? 0)} />
                                    <AttributeRow icon={<Zap className="h-4 w-4" />} label="RES" max={getMaxAttributeStats(data)?.magicResistance} value={attributeStats?.magicResistance ?? 0} />
                                </div>
                                <div>
                                    <h4 className="mb-2 font-semibold">Deployment</h4>
                                    <AttributeRow icon={<ChevronRight className="h-4 w-4" />} label="Cost" max={99} value={attributeStats?.cost ?? 0} />
                                    <AttributeRow icon={<ChevronRight className="h-4 w-4" />} label="Block" max={5} value={attributeStats?.blockCnt ?? 0} />
                                    <AttributeRow icon={<ChevronRight className="h-4 w-4" />} label="Redeploy" max={100} value={attributeStats?.respawnTime ?? 0} />
                                </div>
                            </div>
                        ) : (
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <h4 className="mb-2 font-semibold">Combat Stats</h4>
                                    <AttributeRowSkeleton />
                                    <AttributeRowSkeleton />
                                    <AttributeRowSkeleton />
                                    <AttributeRowSkeleton />
                                </div>
                                <div>
                                    <h4 className="mb-2 font-semibold">Deployment</h4>
                                    <AttributeRowSkeleton />
                                    <AttributeRowSkeleton />
                                    <AttributeRowSkeleton />
                                </div>
                            </div>
                        )}
                    </TabsContent>
                    <TabsContent value="skills">
                        <ScrollArea className="h-[200px] w-full rounded-md border p-4">
                            <div className="flex flex-col gap-6">
                                {skills.length > 0 ? (
                                    skills.map((skill, index) => (
                                        <div className="space-y-1" key={`skill-${index}`}>
                                            <div className="flex w-full flex-row items-center gap-2">
                                                <Image
                                                    alt="Skill"
                                                    height={35}
                                                    src={`https://raw.githubusercontent.com/yuanyan3060/ArknightsGameResource/main/skill/skill_icon_${skill.static?.iconId ?? skill.static?.skillId}.png`}
                                                    style={{
                                                        maxWidth: "100%",
                                                        height: "auto",
                                                    }}
                                                    width={35}
                                                />
                                                <div className="text-md">
                                                    <b className={`${data.defaultSkillIndex === index ? "text-blue-200" : "text-inherit"}`}>{skill.static?.levels[data.mainSkillLvl - 1]?.name}</b>
                                                </div>
                                            </div>
                                            <div className="flex flex-col">
                                                <div className="flex flex-row items-center">
                                                    <span className="text-base">Level {data.mainSkillLvl}</span>
                                                    {skill.specializeLevel > 0 ? (
                                                        <Image
                                                            alt="M1"
                                                            className="h-8 w-8"
                                                            height={50}
                                                            src={`/m-${skill.specializeLevel}_0.webp`}
                                                            style={{
                                                                maxWidth: "100%",
                                                                height: "auto",
                                                            }}
                                                            width={50}
                                                        />
                                                    ) : null}
                                                </div>
                                                <span className="mb-2 text-sm">
                                                    <b>{formatSkillType(skill.static?.levels[parseSkillStaticLevel(data.mainSkillLvl, skill.specializeLevel)]?.spData.spType ?? "")}</b> | <b>Initial: </b>
                                                    <span className="text-muted-foreground">{skill.static?.levels[parseSkillStaticLevel(data.mainSkillLvl, skill.specializeLevel)]?.spData.initSp ?? 0} SP</span> - <b>Cost: </b>
                                                    <span className="text-muted-foreground">{skill.static?.levels[parseSkillStaticLevel(data.mainSkillLvl, skill.specializeLevel)]?.spData.spCost ?? 0} SP</span>
                                                </span>
                                                <span
                                                    className="text-gray-500 text-xs"
                                                    dangerouslySetInnerHTML={{
                                                        __html: descriptionToHtml(
                                                            skill.static?.levels[parseSkillStaticLevel(data.mainSkillLvl, skill.specializeLevel)]?.description ?? "",
                                                            skill.static?.levels[parseSkillStaticLevel(data.mainSkillLvl, skill.specializeLevel)]?.blackboard?.concat({
                                                                key: "duration",
                                                                value: skill.static?.levels[parseSkillStaticLevel(data.mainSkillLvl, skill.specializeLevel)]?.duration ?? 0,
                                                                valueStr: skill.static?.levels[parseSkillStaticLevel(data.mainSkillLvl, skill.specializeLevel)]?.duration?.toString() ?? "",
                                                            }) ?? [],
                                                        ),
                                                    }}
                                                ></span>
                                            </div>
                                        </div>
                                    ))
                                ) : (
                                    <div className="text-gray-500 text-sm dark:text-gray-400">No skills found.</div>
                                )}
                            </div>
                        </ScrollArea>
                    </TabsContent>
                    <TabsContent value="talents">
                        <ScrollArea className="h-[200px] w-full rounded-md border p-4">
                            {operatorData.talents.map((talent, index) => {
                                const parseCandidatePhase = (phase: string) => {
                                    if (phase === "PHASE_0") return 0;
                                    if (phase === "PHASE_1") return 1;
                                    if (phase === "PHASE_2") return 2;
                                    return 0;
                                };

                                let talentIndex = 0;
                                for (let i = 0; i < talent.candidates.length; i++) {
                                    const candidate = talent.candidates[i];
                                    if (data.evolvePhase >= parseCandidatePhase(candidate?.unlockCondition.phase) && data.level >= candidate?.unlockCondition.level && data.potentialRank >= candidate?.requiredPotentialRank) {
                                        talentIndex = i;
                                    }
                                }

                                const currentTalent = talent.candidates[talentIndex];

                                return (
                                    <div className="mb-4" key={index}>
                                        <h3 className="font-semibold">{currentTalent?.name}</h3>
                                        <p className="text-muted-foreground text-sm">{removeStyleTags(currentTalent?.description ?? "N/A")}</p>
                                    </div>
                                );
                            })}
                        </ScrollArea>
                    </TabsContent>
                    <TabsContent value="modules">
                        <ScrollArea className="h-[200px] w-full rounded-md border p-4">
                            {data.static?.modules && data.static.modules.length > 0 ? (
                                <div className="flex flex-col gap-4">
                                    {data.static.modules.map((module, index) => {
                                        const isEquipped = data.currentEquip === module.uniEquipId;
                                        const moduleLevel = data.equip[module.uniEquipId]?.level ?? 0;
                                        const isLocked = data.equip[module.uniEquipId]?.locked === 1;
                                        if (module.typeName1 === "ORIGINAL" || moduleLevel === 0 || isLocked) return null;

                                        return (
                                            <div className="space-y-2" key={`module-${index}`}>
                                                <div className="flex w-full flex-row items-center gap-2">
                                                    <Image
                                                        alt="Module"
                                                        height={35}
                                                        src={`https://raw.githubusercontent.com/fexli/ArknightsResource/main/equip/${module.uniEquipIcon}.png`}
                                                        style={{
                                                            maxWidth: "100%",
                                                            height: "auto",
                                                            objectFit: "contain",
                                                        }}
                                                        width={35}
                                                    />
                                                    <div className="text-md">
                                                        <p className="text-gray-400 text-xs">
                                                            {module.typeName1} {module.typeName2 ? `(${module.typeName2})` : ""}
                                                        </p>
                                                        <b className={isEquipped ? "line-clamp-1 text-blue-200" : "line-clamp-1 text-inherit"}>{module.uniEquipName}</b>
                                                    </div>
                                                </div>
                                                <div className="flex flex-col">
                                                    <div className="flex flex-row items-center">
                                                        <span className="text-base">Level {moduleLevel}</span>
                                                        {isEquipped && <span className="ml-2 text-blue-200 text-sm">(Equipped)</span>}
                                                    </div>
                                                </div>
                                            </div>
                                        );
                                    })}
                                    {!data.static.modules.some((module) => {
                                        const moduleLevel = data.equip[module.uniEquipId]?.level ?? 0;
                                        const isLocked = data.equip[module.uniEquipId]?.locked === 1;
                                        return module.typeName1 !== "ORIGINAL" && moduleLevel > 0 && !isLocked;
                                    }) && <div className="text-gray-500 text-sm dark:text-gray-400">No modules unlocked.</div>}
                                </div>
                            ) : (
                                <div className="text-gray-500 text-sm dark:text-gray-400">No modules available.</div>
                            )}
                        </ScrollArea>
                    </TabsContent>
                </Tabs>
            </CardContent>
        </Card>
    );
}

const getProgressColor = (value: number, max: number) => {
    const percentage = (value / max) * 100;
    if (percentage >= 80) return "bg-green-500";
    if (percentage >= 50) return "bg-yellow-500";
    return "bg-red-500";
};

const AttributeRow = ({ label, value, icon, max = 2000 }: { label: string; value: number; icon: React.ReactNode; max?: number }) => (
    <div className="mb-2 flex items-center space-x-2">
        {icon}
        <span className="w-24 text-sm">{label}</span>
        <Progress className={`h-2 w-full ${getProgressColor(value, max)}`} value={(value / max) * 100} />
        <span className="w-16 text-right text-sm">{value}</span>
    </div>
);

const AttributeRowSkeleton = () => (
    <div className="mb-2 flex items-center space-x-2">
        <Skeleton className="h-4 w-4" />
        <Skeleton className="h-4 w-24" />
        <Skeleton className="h-2 w-full" />
        <Skeleton className="h-4 w-16" />
    </div>
);

export default CharacterDialogueCard;
