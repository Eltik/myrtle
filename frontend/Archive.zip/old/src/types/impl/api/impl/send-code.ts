export type SendCodeResponse = {
    success?: boolean;
    error?: string;
    message?: string;
};
