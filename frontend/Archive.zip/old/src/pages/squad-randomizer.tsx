import Randomizer from "~/components/squad-randomizer";

const SquadRandomizer = () => {
    return (
        <>
            <Randomizer />
        </>
    );
};

export default SquadRandomizer;
